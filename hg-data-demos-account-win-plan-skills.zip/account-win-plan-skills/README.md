# Account Win Plan skills (HG Insights)

Two Claude skills that build an HG Insights **Account Win Plan**: a one-page HTML plan a seller uses to win a target account, built from HG data over MCP.

| Skill | What it does |
|---|---|
| `hg-account-win-plan-research-by-kp-nov-2026` | Picks the target account, pulls HG data (installs, spend, AI, intent, Buying Centers, news, contacts, peers), writes `win-plan-data-*.json` and packages a customer-specific copy of the workflow for the Build Your Own section. |
| `hg-account-win-plan-html-by-kp-nov-2026` | Renders the JSON into one self-contained, on-brand HTML file (`scripts/render_win_plan.py`), or restyles an older plan. No data calls, no credits. |

## Install in Claude
Zip each folder (or use the `.skill` files), then Customize → Skills → Add → Upload a skill. Both skills are needed.

## Plan layout
Quick Start, then §1 Why Now, §2 Opps to Win, §3 Tech Spend, §4 Tech Signals, §5 Intent Signals, §6 News Signals, §7 Peers Comparison, §8 Competitive Battle Card, §9 Contacts & Outreach Drafts, §10 Sources, §11 Build Your Own Account Win Plan.

The JSON contract is `references/win-plan-data-schema.md` (identical in both skills).
