# Build your own account win plan (required closing section) and sample note

Every plan includes this section. It shows the customer (or the HG seller, for an internal plan) that plans like this one can be built from HG data over MCP, with the skill zip embedded as a download.

## Placement
- **Section**: the last section (§11 when every section is present), titled "Build your own account win plan with HG data over MCP", nav link "Build Your Own Account Win Plan".
- **Sample note**: at the top of that section, before its takeaway (not under the hero). A white card with a 6px accent left border.
- Always included, in every plan and for every audience (customer samples and internal HG plans alike). Never drop it.

## Sample note wording (adapt names, keep the meaning, no dashes)
Headline: "This sample win plan uses HG data only. Add [customer]'s own data and it gets sharper."
Paragraph: "Everything in this win plan comes from HG Insights: installs, spend, intent, news and contacts. A [customer] seller gets all of it without anyone connecting a [customer] system. The next step is to bring in what only [customer] knows, so the plan shows HG's view of the market and [customer]'s view of the relationship on one page."
Left column, In this win plan (HG data): the installs that matter at the target account and since when; IT and relevant spend and the addressable share; buyer intent, news and the buying committee.
Right column, Add from [customer] (first-party data): CRM (open opportunities, account owner, last touch, closed-lost reasons); the customer's own product data (which of its products the account already uses, usage, recent findings; tailor to what the customer sells); relationships (which of the customer's people already know these buyers).

## Section wording
Title: "Build your own account win plan with HG data over MCP"
Takeaway (bold): "An LLM produced this win plan by pulling HG data through HG's MCP server. [Customer] can run the same workflow on any account."
Paragraph: "The zip below holds the workflow behind this page. One skill tells the LLM how to pick an account, which data to pull and how to write the plan, and it renders the finished HTML itself, so there is nothing to run. A customer pack holds [customer]'s product IDs, the competitor product IDs, the intent topics and the thresholds."
Download button: a dark block with the accent left border: "Download the workflow", then the zip file name and its size in KB. The link is a base64 `data:application/zip` URI with the `download` attribute, so the HTML stays self-contained. Zip name: `HG Insights - Account Win Plan Skill - [Customer] - [Mon D YYYY].zip`.
Heading "How [customer] would use it", then a numbered list of four steps:
1. **Connect HG's MCP server** to the LLM the customer already uses, such as ChatGPT, Microsoft Copilot, Gemini or Claude. It exposes company search, installs, intent, spend, Buying Centers, reviews, contacts and web search as tools the LLM can call. HG sets up access and credits; state the credits this plan used. **Sign up:** register at phoenix.hginsights.com (https://phoenix.hginsights.com) with a work email (personal addresses are not accepted), then follow the Getting Started guide (https://phoenix.hginsights.com/docs/getting-started) to connect the LLM. More about the product: HG MCP Server (https://hginsights.com/product/hg-mcp-server). Render all three as links.
2. **Install the skill.** Download the zip. Example in Claude: open Customize, then Skills, then Yours, click Add, choose Upload a skill and pick the zip file. Claude installs it as `<customer>-account-win-plan`, and you do not need to unzip it. For Claude Code, unzip it and copy the folder into `~/.claude/skills/`. With another LLM, unzip it and attach `SKILL.md` and the folder's files as the instructions, using an LLM that can run Python.
3. **Ask for a plan.** In a new chat, say "Build me an account win plan." The LLM asks one question, which [customer] product line and optionally which account. It shortlists accounts, you confirm one, and it pulls the data, writes the plan and renders the finished HTML file for you. Every figure comes from a tool result, and gaps are stated as gaps.
4. **Add [customer]'s own data.** Connect the CRM and the customer's own product data as further MCP servers and extend the research skill to read them (see the note above).
Muted last line: the zip contents (SKILL.md, references/, scripts/).

## Rules
- There is no render step for the user: the skill runs `scripts/render_win_plan.py` itself. Do not tell the user to run a script.
- Do not tell the customer to have their teams review the zip; the install steps are the instruction.
- Do not describe features the workflow lacks (no scheduling, no CRM connector shipped). Step 4 is a direction, not a delivered capability.
- Say "LLM", not "AI assistant".
- The word "Render" can trip the publisher's "mentions another customer" warning; it is a warning only.
- No dashes, no HG scoring numbers, no third-party provider names.
