# Account Win Plan: HTML format & house style (HG Insights 2026 brand)

This is the formatting half of the Account Win Plan workflow. Content comes from `win-plan-data.json` (see `win-plan-data-schema.md`) or, in restyle mode, from an existing plan HTML. Do not change content here.

The plan is a single self-contained HTML file. All CSS lives in one inline `<style>` block, and the file has **no external references at all**: no web fonts, scripts, images or stylesheets loaded from a URL. It has to render standalone from disk and print cleanly. This file defines the visual system so every plan looks consistent and on-brand.

Source of truth: *2026 HG Insights Brand Guidelines V1.0* (HGInsights_BrandGuidelines.pdf). If something here conflicts with that guide, the guide wins. Flag the conflict to the user; don't improvise.

## Overall feel

A polished HG Insights "account intelligence deep dive". It opens with a Prussian Blue hero carrying the HG logo and a row of headline stat tiles, then a numbered (§) sticky section nav, then clean white content cards on a warm Floral White page. Prussian Blue and the warm neutrals carry the page. Vibrant Coral is the signal: it marks the few things that matter most and never decorates. The voice is proof first: every data block shows its source.

## HG brand system (use these exactly)

### Core colors
| Token | Hex | Use |
|---|---|---|
| Prussian Blue | `#071834` | Hero and nav background, headings, table headers, body text, primary dark foundation |
| Vibrant Coral | `#FF4A4A` | Signature accent, **used sparingly**: the rule under each `<h2>`, hero stat numbers, Displacement tags, Primary Threat cells, nav § numbers and the active/hover underline |
| Natural Linen | `#EFE4DC` | Alt fills, callouts, notes, striped table rows, chip backgrounds |
| Floral White | `#FBF6EC` | Page background, light text on Prussian Blue |
| White | `#FFFFFF` | Content cards |

### Supporting tints (from the guide)
- Coral: 80% `#ED7773` · 60% `#F09895` · 40% `#F4BAB8` · 20% `#F9DCDB`
- Prussian Blue: 80% `#3B465B` · 60% `#6C7484` · 40% `#9DA2AD` · 20% `#CED1D6`

Use `#6C7484` for muted text (source lines, attributions, captions) and `#CED1D6` for borders and gridlines.

### Presentation accents (charts, data viz, categorical coding)
Blue `#3B5BDB` · Green `#0CA678` · Purple `#9C36B5` · Orange `#F08C00`

These separate categories (opportunities, chart series). They are not page chrome. Links use Blue `#3B5BDB`.

The guide reserves its status colors (Success `#2F9E44`, Warning `#F08C00`, Info `#1971C2`, Error `#E03131`) for functional UI states. A plan has no UI states, so don't use them.

### Contrast rules (WCAG AA, from the guide)
- Body text: Prussian Blue (or black) on white, Floral White or Natural Linen. White or Floral White on Prussian Blue.
- Coral **text** only at large sizes (≥24px, or ≥19px bold): hero stat numbers and large figures. Never small coral text on light backgrounds, and never coral text on Natural Linen (2.7:1).
- White text on a coral fill is large-text only (3.1:1). For small chips, use a light tint background with Prussian Blue text, and carry the color in a dot or left bar.
- White text on Green `#0CA678` fails AA. Never put small white text on green.
- Color is never the only carrier of meaning. Every colored chip, cell or line also has a text label.

### Typography
Font stack everywhere: `font-family: "Google Sans", Arial, Helvetica, sans-serif;` with no `@import` and no `<link>`. Google Sans renders where the reader has it installed; everyone else gets Arial. Don't reference Nunito Sans, Neue Haas Grotesk or Basic Sans.
- Headings: weight 700, Prussian Blue, tight letter-spacing (`-0.01em`). Hierarchy comes from scale, weight and spacing, not decoration.
- Body: ~16px, line-height ~1.55, Prussian Blue.
- Within a heading, coral may emphasise one key word or figure. Never color whole passages coral.

### Logo
- Files: `assets/hg-logo-white.png` (reversed: white wordmark, coral icon) for the Prussian Blue hero, and `assets/hg-logo-color.png` (full color: Prussian Blue wordmark, coral icon) for light backgrounds. Both were extracted from the approved artwork in the brand guidelines.
- Embed as a base64 data URI (`<img src="data:image/png;base64,…" alt="HG Insights">`) so the file stays self-contained.
- Minimum height 24px; ~28–32px in the hero. Keep clear space equal to the icon height on all sides.
- Never stretch, recolor, rotate, add shadows, glows or outlines, or place the logo on a busy or low-contrast background.
- If the logo files are missing, fall back to a plain text "HG Insights" label in the same position and keep building.

## Layout

- **Container**: centered, max-width ~1180px, white cards on the Floral White page (`#FBF6EC`). Text spans the full container width; don't cap text blocks with max-width or `ch`.
- **Save space**: wherever two or more cards, groups or emails of the same kind sit in a row, use a two-column grid (`.g2c`, one column on narrow screens): opportunity cards, intent cards, news groups, head-to-head cards, insights, email drafts. Never stack long single-column lists where two columns fit.
- **Hero**: full-width solid Prussian Blue, no gradient. Top row: white HG logo left, small coral "Account & Contacts Intelligence" kicker right. Then the eyebrow in Floral White at ~75% opacity: **"Account Win Plan · Prepared for [customer] on [Mon D, YYYY]"** (date from `meta.prepared_date`; the only place "Prepared for" appears). Then the target account as a large white `<h1>`, the one-line subtitle, the tag chips, and 4 to 6 **hero stat tiles**: revenue, employees, rank and only the spend categories relevant to the opportunities (e.g. Project and Portfolio Management). **Never put Total IT spend or Total AI spend in the hero**; they belong in the Projected IT Spend table. There is no "Prepared for … · Powered by HG Insights" line under the tiles.
  - Tags are `{label, value}` pairs rendered "Label: value" so they read on their own: **Motion** (e.g. "Win-back of a former HG customer"), **Industry (HG)**, **HQ** (city and country, not a region like "North America").
  - When a Motion tag exists, there is **no account-status chip** (it would repeat the motion). The plain-word status goes in Quick Start.
- **Sticky section nav**: Prussian Blue bar, 3px coral bottom border, centered, wraps instead of scrolling, compact padding (~11px). Links in this order: **▶ Quick Start** (unnumbered), then numbered §1 Why Now · §2 Opps to Win · §3 Tech Spend · §4 Tech Signals · §5 Intent Signals · §6 News Signals · §7 Peers Comparison · §8 Competitive Battle Card · §9 Contacts & Outreach Drafts · §10 Sources · §11 Build Your Own Account Win Plan (always present). Numbers are assigned in order to the sections present, so dropping Peers renumbers the rest. Never a Buying Centers, Snapshot, Outreach or Appendix link.
- **Section headings** (sentence case, `§n` prefix): "Why now: [short name]", "Opps to win", "Tech spend", "Tech signals", "Intent signals", "News signals", "Peers comparison", "Competitive battle card", "Contacts and outreach drafts", "Sources", "Build your own account win plan with HG data over MCP".
- **Section rhythm**: white card, `<h2>` with a ~48×3px coral bar, the bold takeaway, the content, a small muted source line.
- **Print**: hide the nav, white page, `break-inside: avoid` on cards and tables, `-webkit-print-color-adjust: exact`.

## Semantic color coding

- **Opportunity coding**: Opp 1 → Blue `#3B5BDB` · Opp 2 → Green `#0CA678` · Opp 3 → Purple `#9C36B5`. Chips are Natural Linen pills with Prussian Blue text and a colored dot, labelled "Opp 1/2/3". Every block that supports an opportunity carries its chip: Quick Start signals, focus and angles, opp cards (top border), spend pools and rows, installs, the trend series and event lines, AI tiles, peer rows, intent cards, news groups, battle-card columns and head-to-heads, Buying Centers rows, contact cards, emails and source rows. Names are number first: "Opp 1: [name]".
- **Intent context tags**: Displacement → coral tint · Whitespace → Blue · Expansion → Purple · Complementary → `#6C7484`; light backgrounds, Prussian Blue text, colored dot or bar.
- **Competitive threat scale**: Primary Threat → `#F9DCDB` background, 4px coral left border, bold · Active → Natural Linen, 4px Blue border · **Watch → bright yellow `#FFF3BF` background, 4px `#F59F00` left border, bold** so it stands out (this replaces the old "no amber" rule) · Not a factor → muted text, no border. A legend under the matrix defines all four in plain words.
- **Priority tiers**: Priority 1 → solid Prussian Blue chip · Priority 2 → `#6C7484` · Priority 3 → `#CED1D6` with Prussian Blue text.
- **Plain-word levels** (never show the raw number in the body): Use level Heavy / Moderate / Light; AI maturity Early / Developing / Advanced; intent Strong / Moderate signal with trend; cloud use High / Medium / Low. Raw values go in Sources.

## Components (in page order)

**Quick Start** (`quick_start`, first section, id `quickstart`): eyebrow "60-second read · quick start", heading "[short] in one minute", the summary, then two columns:
- *Left*: **1 Why now signals**: one block per opportunity (headline, Opp chip, detail, bold "So what:", muted source). Under them, "[short] customer status:" (`quick_start.status`, plain words, no "LAPSED"-style labels) and "Competition:".
- *Right*: **2 Where to focus**: one card per opportunity, contact first ("Opp 1: name", contact, why). Optional "Check first" box only when `check_first` exists. Then **3 Suggested messaging angle** directly under it: `angle_intro`, the angles stacked (each with its Opp chip), and the muted line "These are sample messaging angles…". Then the **Call or send first** box: one line for the call (focus contact for `call.opp_ids`, linking to `#talktrack`), one line per email ("Email, “subject”", linking to `#email-n`), and a muted line that the talk track and full email drafts are in §9.
- Closing line: "The rest of this win plan goes into detail to help you earn [short]'s business."

**§1 Why now (takeaway + exactly 2 paragraphs)**: paragraph 1 is why this account, why now; paragraph 2 is what the seller can do to earn the business. No tool names, scores, intensity, verification dates or methodology. Then the box **"Your relationship with [short]: add from your CRM"** listing `relationship_prompts` (or defaults by status). The plan is a template customers use, and HG has no access to their CRM, so this box asks the seller to fill in the relationship history; it never claims to know it. The 2×2 matrix renders only when `show_matrix` is true.

**§2 Opps to win**: 1 to 3 cards in a two-column grid, never padded. Top border in the opp color; priority chip; optional wedge chip; "Opp N: name"; body; muted "Why this priority:" and "Entry timeline:"; optional "Wedge step:". Muted source: the framing is a read, not an HG data point.

**§3 Tech spend**: takeaway (`takeaways.spend`). One pool card per opportunity (core label and amount, the lines that make it up, optional caveat). Overlap and not-addressable notes as muted caveats. Then ONE table titled **"Projected IT Spend"**: IT rows with an Opportunity chip column, then a divider row "AI spend (part of Total IT above; do not add)" and the `ai_rows` (total rows bold, child rows indented). `ai_note` sits above the table.

**§4 Tech signals**:
1. Installs table: Product, Vendor, Installed (first → last verified), Departments (only when there is no Buying Centers block), **Use level**, Opportunity. Under it the "Use level:" definition.
2. **Install trend** (`trend_story`): inline SVG, one line per opportunity (summed detection days, opp color), optional shaded band, numbered markers. Under it "What the numbered markers show": one line per event (date, body, chips) and the muted note. Self-contained SVG only, no JS. Never invent periods or values.
3. **AI maturity** (`ai_maturity`): four tiles, each with its title (AI maturity, AI products in use, Data maturity, Cloud mix), a plain-word value, a detail line, an optional stacked list (top AI products; cloud providers one per line with High/Medium/Low) and chips; then "What it means" and the source note.

**§5 Intent signals**: bold "What this means for you" takeaway and `so_what`, scope note. **"Contextual Intent activity patterns (bidstream)"**: cards in two columns tagged "Contextual Intent (bidstream)" with a strength word and trend ("Strong signal, rising"), never the score. **"TrustRadius buyer intent patterns"**: always present; each pattern lists its window, counts and activities (comparisons, pricing pages) and what it means; with none, the line "No relevant TrustRadius intent." TrustRadius activity is buyer intent, never "first-party". Then "Supporting context: moderate Contextual Intent (not used to place the account)" without raw scores.

**§6 News signals**: default takeaway "Here is the relevant news to know about in your conversations with people at [short]." Groups per opportunity in two columns; each item: linked headline, source and date, one-line why it matters. Never fabricate a headline, outlet or date.

**§7 Peers comparison** (optional): takeaway; table with the target and up to 3 peers (metric rows with chips: size, IT and AI spend, AI and data maturity, relevant installs, intent); note; insights in two columns; source.

**§8 Competitive battle card**: heat matrix with one column per opportunity ("Opp N: name"), rows per competitor with a muted HG-evidence sub-line, cells by the threat scale, legend underneath. Then **head-to-head cards**: Opp chip, "us vs them", optional "At [short]:" line, their angle, our counter, trap question. Each fact appears once; don't repeat the matrix in prose. Quotes as coral-bordered blockquotes with reviewer and link only when found; otherwise the muted line "No TrustRadius review quotes matched…". Never a reseller block.

**§9 Contacts and outreach drafts**:
1. Bold `lead_with` takeaway.
2. **Buying Centers panel** (visually separate: Natural Linen, 6px Prussian left border, "Buying Centers" tag), heading "Where the teams sit, and who decides", then the muted note **"How HG picks the contacts below: HG Insights Buying Centers (HG's Functional Area Intelligence) show which departments, roles and locations use each product most. HG then picks contacts whose titles and locations match those teams…"**. Table: Technology and opportunity · Departments · Lead locations · Likely contacts (matched by title; confirm). Insights in two columns, source note. Spelling out "HG's Functional Area Intelligence" once here is fine; never write "FAI" or `company_fai`.
3. A divider headed **"Contacts"** with "Chosen to match the Buying Centers above, then grouped by role in the deal. Executive sponsors come from public sources." Then (unless `audience` is internal) the DPA note. Contact cards in groups: name, title, location, **"At [short]: since Mon YYYY"** tenure, then either the public-source line or **blurred Email and Mobile placeholders** with the note that HG provides them once the customer signs a DPA; Opp chips; "Angle:"; optional opening line.
4. **"Outreach drafts"** (`#outreach`): takeaway, the **talk track** box (`#talktrack`: opener, questions, ask, what to avoid) from `quick_start.call`, then the emails side by side (`#email-1`, `#email-2`), each headed by its chips and To / From / Subject.

**§10 Sources**: table Section · Source · Supports (chips), pull date, frozen-data list, credits used, the TrustRadius-vs-bidstream confidence note, and **"Raw HG values behind the plain-word labels"** (`sources.raw_values`). Source lines say "HG Insights [data set]" (Firmographic, Technographic, Spend, AI spend, AI maturity, Intent, Buying Centers, Contacts), never tool names.

**§11 Build your own account win plan** (always included, for every audience): see `references/build-your-own.md`. The "this sample uses HG data only" note sits at the top of this section, not under the hero.

## Copy discipline

- Lead with the takeaway; data supports it. Tell each story once.
- Plain words for a seller; raw HG values only in Sources.
- Attribute every number to its HG data set. Keep HG data, research and synthesis ("our read") separate.
- No fabricated figures. If something is missing: "No HG data available for X."
- TrustRadius: first visible mention "TrustRadius, an HG Insights Company", later mentions "TrustRadius".
- Name competitors at the account; never name HG's contact-data providers, and never name the seller's other customers to the account.
