# win-plan-data.json: handoff contract

The research skill writes `win-plan-data-[company]-[YYYY-MM-DD].json`. The HTML skill (`hg-account-win-plan-html-by-kp-nov-2026`) reads it and renders the plan (`scripts/render_win_plan.py`). Keep this file identical in both skills. Omit an optional key when the data can't support it; the renderer drops that block (and its nav link, for whole sections). Use `null` for an unknown value, never a guess.

Rules that apply to every text field:
- Plain words for sellers. HG raw values (intensity counts, intent scores, AI maturity scores, cloud shares) never appear in body text; they go in `sources.raw_values`. Use the plain-word bands in the research skill.
- Each story is told once, in the section that owns it. Other sections point to it ("see Why Now") instead of repeating it.
- Opportunities are named number first: "Opp 1: [name]" (or "Opp 1"). `opportunities.items[].name` stays the bare name.
- `opp_id` / `opp_ids` tie every data block to the opportunity it supports ("opp1", "opp2", "opp3"). The renderer turns them into colored Opp chips.

```json
{
  "meta": {
    "customer": "the seller's company", "target_account": "legal name", "target_short": "short name",
    "target_domain": "", "product_line": "", "prepared_date": "YYYY-MM-DD",
    "account_status": "CURRENT | LAPSED | NET-NEW",
    "status_short": "OPTIONAL plain meaning of the status, e.g. 'former HG customer, HG product not seen since Feb 2025'",
    "status_note": "HG-detected caveats (not rendered; for the record)",
    "quadrant": "Expansion | Churn risk | Displacement | Competitor entrenched | Whitespace",
    "audience": "customer | internal",  // internal = for the seller's own team: hides only the DPA note. Build Your Own is shown for every audience
    "pack_version": "", "credits_used": "number or range"
  },
  "header": {
    "one_liner": "",
    "tags": [{"label": "Motion", "value": "Win-back of a former HG customer"},
             {"label": "Industry (HG)", "value": ""}, {"label": "HQ", "value": "City, Country"}],
    // A tag labelled "Motion" replaces the account-status chip (the status lives in Quick Start instead). Plain strings still work.
    "stats": [{"label": "", "value": "", "source": "HG Insights Firmographic"}]  // 4 to 6 tiles: revenue, employees, rank and the spend categories relevant to the opportunities. Never Total IT spend or Total AI spend (they stay in Tech spend)
  },

  "quick_start": {  // Section "Quick Start", first in the nav, unnumbered
    "summary": "2 to 3 sentences: the account, the moment, the play",
    "why_now": [{"headline": "", "opp_ids": ["opp1"], "detail": "", "so_what": "", "source": "HG intent data (directional)."}],  // 1 per opportunity
    "status": "plain sentence for '[Account] customer status:' (no label jargon like LAPSED)",
    "competition": "plain sentence for 'Competition:'",
    "focus": [{"opp_id": "opp1", "contact": "Name, Title (City)", "why": ""}],  // 1 per opportunity, contact first
    "check_first": "OPTIONAL. Omit unless there is a real pre-outreach check",
    "angle_intro": "", "angles": [{"opp_id": "opp1", "question": ""}],  // sample discovery questions, not scripts
    "call": {"opp_ids": ["opp1"], "opener": "", "questions": [""], "ask": "", "avoid": ""}
    // call is rendered as the talk track in §9; Quick Start links to it in "Call or send first"
  },

  "why_now": {
    "paragraphs": ["takeaway", "why this account, why now", "what the seller can do to earn the business"],
    // Exactly 3 strings; the renderer stops otherwise. ~80-100 words per paragraph. No tool names, scores, intensity, dates of verification or methodology.
    "relationship_prompts": ["OPTIONAL. Questions the seller answers from their own CRM; defaults by account_status if omitted"],
    "show_matrix": false, "matrix": {}  // OPTIONAL 2x2 graphic, off by default (keys as before: own_installed_own_intent, ..., whitespace, filter_note)
  },

  "opportunities": {
    "items": [{"id": "opp1", "name": "bare name", "body": ""}],  // 1 to 3; never pad
    "matrix": [{"opp_id": "opp1", "tier": "Near | Mid | Long", "rationale": "", "timeline": ""}],
    "wedge": [{"phase": "Entry | Expansion | Full account", "body": ""}]  // OPTIONAL, by index
  },

  "tech_spend": {
    "directly_addressable": "", "total_it_budget": "",
    "pools": [{"opp_id": "opp1", "core_label": "", "core_amount": "", "lines": [{"label": "", "amount": ""}], "caveat": "OPTIONAL"}],
    "overlap_note": "OPTIONAL: which lines are parts of others (do not add)",
    "not_addressable_note": "OPTIONAL: lines that are context only and why",
    "rows": [{"category": "", "amount": "", "opp_id": "opp1|null", "addressable": false, "note": ""}],  // IT rows; first row is Total IT
    "ai_rows": [{"category": "Total AI spend", "amount": "", "total": true, "child": false, "opp_ids": [], "note": ""}],  // OPTIONAL; shown under a divider "AI spend (part of Total IT above; do not add)"
    "ai_note": "OPTIONAL note shown above the Projected IT Spend table",
    "source": ""
  },

  "tech_signals": {
    "installs": [{"product": "", "vendor": "", "deployment": "Mon YYYY to Mon YYYY (older than 12 months, if stale)",
                  "departments": "", "intensity": 0, "opp_id": "opp1|null"}],
    // intensity is a raw HG value: the renderer converts it to Use level (Heavy >=50% of the highest in the table, Moderate >=15%, Light below) and never shows the number
    "intensity_definition": "definition shown after 'Use level:'",
    "trend_story": {  // OPTIONAL; replaces the old install_trend chart
      "title": "", "takeaway": "",
      "periods": ["Mon YYYY", "..."],  // 12 to 36 months, oldest first
      "series": [{"name": "Opp 2: product + product", "opp_id": "opp2", "values": [0, null]}],  // summed detection days per opportunity; null = not detected; opp_id null = context line in gray (e.g. the host platform)
      "bands": [{"from": "Mon YYYY", "to": "Mon YYYY"}],  // OPTIONAL shaded change window
      "markers": [{"n": 1, "period": "Mon YYYY"}],
      "events": [{"n": 1, "date": "Mon YYYY", "body": "one line", "opp_ids": ["opp2"]}],  // explains each numbered marker
      "note": "what the chart shows and does not show"
    },
    "ai_maturity": {  // OPTIONAL; rendered under the trend
      "opp_ids": ["opp1"],
      "tiles": [{"title": "AI maturity | AI products in use | Data maturity | Cloud mix", "value": "plain word",
                 "detail": "", "list": ["OPTIONAL stacked lines, e.g. 'Google Cloud: High'"], "opp_ids": []}],
      "meaning": "What it means for the seller", "note": "source line"
    },
    "teams": {  // Buying Centers; rendered inside §9 Contacts, not in Tech Signals
      "takeaway": "",
      "rows": [{"technology": "", "opp_ids": ["opp2"], "departments": "Sales 81%, Marketing 19%",
                "locations": "", "contacts": "Names (titles) matched to this team"}],
      "insights": [{"heading": "", "body": "", "opp_ids": ["opp2"]}],
      "note": "Source: HG Insights Buying Centers ..."
    },
    "source": ""
  },

  "peers": {  // OPTIONAL section "Peers comparison"
    "takeaway": "", "columns": ["Target", "Peer 1", "Peer 2", "Peer 3"],
    "rows": [{"metric": "", "opp_ids": [], "values": ["", "", "", ""]}],
    "note": "", "insights": [{"heading": "", "body": "", "opp_ids": []}], "source": ""
  },

  "intent": {
    "scope_note": "", "so_what": "",
    "cards": [{"topic": "", "context_type": "Displacement|Whitespace|Expansion|Complementary", "confidence": "Bidstream|TrustRadius",
               "score": 0, "trend": "rising|steady|falling", "last_seen": "", "page_type": null, "products_compared": [],
               "url": null, "meaning": "", "opp_id": "opp1"}],
    // Bidstream cards render under "Contextual Intent activity patterns (bidstream)" with a strength word (Strong >=85, Moderate 65-84), never the score
    "tr_patterns": {  // always rendered; with no patterns it says "No relevant TrustRadius intent."
      "patterns": [{"title": "", "opp_ids": ["opp2"], "window": "", "counts": "",
                    "activities": [{"date": "", "label": "Comparison (3 views)", "products": ""}], "meaning": ""}],
      "summary": "caveat on the rest of the TrustRadius activity"
    },
    "supporting_context": [{"topic": "", "score": 0, "note": "", "opp_id": "opp2"}]  // moderate topics, not used to place the account
  },

  "news": [{"opp_id": "opp1", "items": [{"headline": "", "source": "", "date": "", "why": "", "url": ""}], "none_found": false}],

  "competitive": {
    "landscape": {"plays": ["one per opportunity"], "opp_ids": ["opp1", "opp2"],
      "rows": [{"vendor": "", "signal": "HG install/intent evidence", "threat_by_opp": ["Primary Threat|Active|Watch|Not a factor"]}]},
    "head_to_head": [{"opp_id": "opp1", "us": "", "them": "", "at_account": "OPTIONAL what is true at this account",
                      "their_angle": "", "our_counter": "", "trap_question": ""}],  // from the seller's win/battle-card pages
    "hg_reveals": "OPTIONAL", "quotes": [{"text": "", "reviewer": null, "url": null}], "angle": "OPTIONAL"
  },

  "contacts": {
    "lead_with": "",
    "groups": [{"role": "Executive sponsors (public sources) | Opp 1 lead | ...", "people": [{
      "name": "", "title": "", "location": "", "tenure": "since Mon YYYY (from employment history)",
      "opp_ids": ["opp1"], "angle": "", "opening_line": "OPTIONAL",
      "public_source": "OPTIONAL: for people found in public sources; replaces the blurred email/mobile placeholders"}]}]
  },

  "outreach": [{"to": "", "from": "[Your name]", "subject": "", "body": "", "opp_ids": ["opp1"]}],  // one per opportunity; rendered in §9 with ids email-1, email-2

  "takeaways": {"opps": "", "spend": "", "signals": "", "intent": "What this means for you: ...", "news": "OPTIONAL", "competitive": "", "outreach": ""},

  "sources": {"rows": [{"section": "", "tool": "", "opp_ids": []}], "pull_date": "", "confidence_note": "",
              "raw_values": "Raw HG values behind the plain-word labels (intensity, scores, maturity, cloud shares)"},

  "build_your_own": {"include": true, "zip_name": "HG Insights - Account Win Plan Skill - <Customer> - <Mon D YYYY>.zip",
                     "zip_path": "local path to embed", "skill_folder": "<customer>-account-win-plan", "credits_used": 0}
  // Required in every plan: the Build Your Own section (§11) is always included, for customer and internal audiences.
}
```

Legacy keys still accepted by the renderer (don't write them in new plans): `tech_signals.install_trend`, `tech_signals.buying_centers`, `competitive.landscape.play_opps` / `threat_by_play`, `competitive.findings`.
