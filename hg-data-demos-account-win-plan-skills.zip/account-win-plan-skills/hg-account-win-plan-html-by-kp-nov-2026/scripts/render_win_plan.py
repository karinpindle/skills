#!/usr/bin/env python3
"""Render an HG account win plan HTML from a win-plan-data JSON.

Usage: python render_win_plan.py win-plan-data.json hg-logo-white.png out.html [workflow.zip] [--brand brand.json]

Default look is the 2026 HG brand. --brand takes a JSON file (see assets/brand-securin.json) with the
customer's colors, font and logo; the customer logo then sits top left with "Powered by HG Insights".
The zip, when given, is embedded as a download in the optional last section.
"""
import base64, html, json, os, re, sys

_args = sys.argv[1:]
brand_path = None
if "--brand" in _args:
    i = _args.index("--brand")
    brand_path = _args[i + 1]
    del _args[i:i + 2]
data_path, logo_path, out_path = _args[0], _args[1], _args[2]
workflow_zip = _args[3] if len(_args) > 3 else None  # optional: embeds a download link in the last section

B = {"logo": None, "pb": "#071834", "co": "#FF4A4A", "cod": "#FF4A4A", "tl": "#F9DCDB", "nl": "#EFE4DC", "fw": "#FBF6EC",
     "mu": "#6C7484", "bd": "#CED1D6", "bl": "#3B5BDB", "gr": "#0CA678", "pu": "#9C36B5",
     "opp": ["#3B5BDB", "#0CA678", "#9C36B5"], "font": '"Google Sans",Arial,Helvetica,sans-serif'}
if brand_path:
    _b = json.load(open(brand_path))
    B.update({k: v for k, v in _b.items() if k != "logo"})
    if _b.get("logo"):
        B["logo"] = os.path.join(os.path.dirname(os.path.abspath(brand_path)), _b["logo"])
D = json.load(open(data_path))
e = lambda s: html.escape(str(s), quote=True)

OPP = {"opp1": ("Opp 1", B["opp"][0]), "opp2": ("Opp 2", B["opp"][1]), "opp3": ("Opp 3", B["opp"][2])}
opp_names = {o["id"]: o["name"] for o in D["opportunities"]["items"]}

def chip(opp_id):
    if not opp_id or opp_id not in OPP:
        return ""
    label, color = OPP[opp_id]
    return f'<span class="oppchip" style="--c:{color}"><i></i>{label}</span>'

def oname(opp_id):
    """Opportunity name with its number in front: "Opp 1: Name". Never doubles a prefix already in the JSON."""
    name = re.sub(r"^\s*Opp\s*[123]\s*[:.\-]?\s*", "", str(opp_names.get(opp_id, "")), flags=re.I)
    return f"{OPP[opp_id][0]}: {name}"

def named_chip(opp_id):
    label, color = OPP[opp_id]
    return f'<span class="oppchip" style="--c:{color}"><i></i>{e(oname(opp_id))}</span>'

def chips(ids):
    if isinstance(ids, str):
        ids = [ids]
    return " ".join(chip(i) for i in (ids or []))

def para(s):
    return f"<p>{e(s)}</p>"

def src(s):
    return f'<p class="src">{e(s)}</p>'

logo = base64.b64encode(open(logo_path, "rb").read()).decode()
brandlogo = base64.b64encode(open(B["logo"], "rb").read()).decode() if B["logo"] else None
M, H = D["meta"], D["header"]
CUST = e(M["customer"])
BYO = D.get("build_your_own") or {}
INTERNAL = M.get("audience") == "internal"  # plan for the seller's own team, not a customer sample
show_byo = bool(workflow_zip) or bool(BYO.get("include"))  # always shown when a zip is given, for every audience
skill_folder = BYO.get("skill_folder") or (re.sub(r"[^a-z0-9]+", "-", M["customer"].lower()).strip("-") + "-account-win-plan")
TK = D.get("takeaways", {})
import datetime as _dt
try:
    _pd = _dt.date.fromisoformat(M["prepared_date"])
    PULL_MONTH = _pd.strftime("%B %Y")
    PREP_DATE = _pd.strftime("%b ") + str(_pd.day) + _pd.strftime(", %Y")
except Exception:
    PULL_MONTH = PREP_DATE = str(M.get("prepared_date", ""))
def tk(key, default):
    return e(TK.get(key, default))

css = """
:root{--pb:@@pb;--co:@@co;--cod:@@cod;--tl:@@tl;--nl:@@nl;--fw:@@fw;--wh:#fff;--mu:@@mu;--bd:@@bd;--bl:@@bl;--gr:@@gr;--pu:@@pu}
*{box-sizing:border-box}
body{margin:0;background:var(--fw);color:var(--pb);font-family:@@font;font-size:16px;line-height:1.55;-webkit-print-color-adjust:exact;print-color-adjust:exact}
a{color:var(--bl)}
h1,h2,h3,h4{font-weight:700;letter-spacing:-0.01em;color:var(--pb);margin:0}
.hero{background:var(--pb);color:var(--fw);padding:28px 0 32px}
.wrap{max-width:1180px;margin:0 auto;padding:0 24px}
.toprow{display:flex;justify-content:space-between;align-items:center}
.toprow img{height:22px;opacity:.9}.secwm{height:34px;display:block}.kicker{color:var(--co)}.poweredby{display:flex;align-items:center;gap:10px;font-size:12px;opacity:.85}
.kicker{color:var(--co);font-weight:700;font-size:13px;letter-spacing:.08em;text-transform:uppercase}
.eyebrow{margin-top:26px;opacity:.75;font-size:14px}
.hero h1{color:#fff;font-size:42px;margin:6px 0 8px}
.sub{font-size:18px;color:var(--fw);margin:0 0 14px}
.chips{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:10px}
.chip{background:rgba(255,255,255,.12);color:var(--fw);padding:4px 12px;border-radius:99px;font-size:13px}
.status{border:1px solid var(--fw);color:var(--fw);padding:4px 12px;border-radius:99px;font-size:13px;font-weight:700}
.statusnote{opacity:.7;font-size:13px;margin-left:6px}
.tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin:20px 0 14px}
.tile{background:rgba(255,255,255,.06);border:1px solid rgba(251,246,236,.18);border-radius:10px;padding:14px}
.tile b{display:block;color:var(--co);font-size:30px;line-height:1.1}
.tile span{display:block;font-size:13px;margin-top:4px}
.tile em{display:block;font-style:normal;font-size:11px;opacity:.6;margin-top:2px}
.prep{font-size:13px;opacity:.8}
nav{position:sticky;top:0;z-index:5;background:var(--pb);border-bottom:3px solid var(--co);padding:11px 12px;display:flex;flex-wrap:wrap;justify-content:center;gap:4px 22px}
nav a{color:var(--fw);text-decoration:none;font-size:14px;border-bottom:2px solid transparent}
nav a b{color:var(--co);margin-right:4px}
nav a:hover{color:#fff;border-bottom-color:var(--co)}
section{background:var(--wh);margin:22px 0;padding:28px;border-radius:12px;border:1px solid var(--bd)}
section h2{font-size:26px;padding-bottom:10px;position:relative;margin-bottom:16px}
section h2:after{content:"";position:absolute;left:0;bottom:0;width:48px;height:3px;background:var(--co)}
h3{font-size:18px;margin:22px 0 8px}
.take{font-weight:700;font-size:18px}
.src{color:var(--mu);font-size:13px;margin:14px 0 0}
table{width:100%;border-collapse:collapse;font-size:14px;margin:10px 0}
th{background:var(--pb);color:#fff;text-align:left;padding:9px 10px;font-weight:700}
td{padding:9px 10px;border-bottom:1px solid var(--bd);vertical-align:top}
tbody tr:nth-child(even) td{background:var(--nl)}
tr.total td{font-weight:700}
.addr td:first-child{border-left:3px solid var(--co)}
.badge{display:inline-block;font-size:11px;font-weight:700;background:var(--nl);padding:1px 7px;border-radius:99px;margin-left:6px}
.oppchip{display:inline-flex;align-items:center;gap:6px;background:var(--nl);color:var(--pb);border-radius:99px;padding:2px 10px;font-size:12px;white-space:nowrap}
.oppchip i{width:9px;height:9px;border-radius:50%;background:var(--c);display:inline-block}
.grid3{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:14px}
.card{border:1px solid var(--bd);border-top:3px solid var(--c,var(--pb));border-radius:8px;padding:14px;background:var(--wh)}
.card h4{font-size:16px;margin:6px 0}
.pchip{display:inline-block;font-size:12px;font-weight:700;padding:2px 10px;border-radius:99px}
.p1{background:var(--pb);color:#fff}.p2{background:var(--mu);color:#fff}.p3{background:var(--bd);color:var(--pb)}
.phase{border-left:4px solid var(--pb);padding:6px 14px;margin:10px 0;background:var(--fw)}
.phase.entry{border-left-color:var(--co)}
.quad{display:grid;grid-template-columns:140px 1fr 1fr;gap:8px;margin:14px 0 6px;font-size:14px}
.quad div{padding:10px;border-radius:6px}
.qh{font-weight:700;background:transparent!important;color:var(--mu)}
.qc{background:var(--nl);color:var(--mu)}
.qc b{display:block;color:var(--mu);margin-bottom:4px}
.qc.hot{border:2px solid var(--co);background:var(--wh);color:var(--pb)}
.qc.hot b{display:inline-block;background:var(--tl);color:var(--pb);padding:1px 8px;border-radius:99px}
.strip{background:var(--nl);color:var(--mu);padding:10px;border-radius:6px;font-size:14px}
.callouts{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:16px}
.big{font-size:44px;font-weight:700;color:var(--cod);line-height:1}
.sig{border:1px solid var(--bd);border-left:4px solid var(--mu);border-radius:8px;padding:12px 14px;margin:10px 0}
.tag{display:inline-block;font-size:12px;padding:2px 10px;border-radius:99px;background:var(--nl);margin:0 6px 6px 0;color:var(--pb)}
.tag.disp{background:var(--tl);border-left:3px solid var(--co)}
.tag.comp{border-left:3px solid var(--mu)}
.sig.disp{border-left-color:var(--co)}
.newsgrp{border-left:4px solid var(--c);padding:2px 0 2px 14px;margin:14px 0}
.newsitem{margin:10px 0}
.meta{color:var(--mu);font-size:13px}
.heat td.cell{border-left:4px solid transparent}
.t-p{background:var(--tl);border-left-color:var(--co)!important;font-weight:700}
.t-a{background:var(--nl);border-left-color:var(--bl)!important}
.t-w{background:#FFF3BF;border-left-color:#F59F00!important;font-weight:700}
.t-n{color:var(--mu);background:var(--wh)}
.legend{font-size:13px;color:var(--mu)}
blockquote{border-left:3px solid var(--co);background:var(--nl);margin:12px 0;padding:10px 14px}
.contact{border:1px solid var(--bd);border-radius:8px;padding:12px;background:var(--wh)}
.contact h4{margin:0 0 2px}
.email{background:var(--nl);padding:14px 16px;border-radius:8px;margin:12px 0;white-space:pre-wrap}
.email .hd{color:var(--mu);font-size:13px}
.note{background:var(--nl);padding:10px 14px;border-radius:8px;font-size:14px}
.dq{background:var(--wh);border:1px solid var(--bd);border-left:6px solid var(--co);border-radius:12px;padding:22px 26px;margin:6px 0 22px}.dq h2{font-size:21px;margin:0 0 8px}.dq p{margin:0 0 12px}.dq .cols{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:14px}.dq .col{border-radius:8px;padding:14px 16px;background:var(--nl)}.dq .col.add{background:var(--tl);border:1px solid var(--co)}.dq .col h4{font-size:14px;letter-spacing:.04em;text-transform:uppercase;margin:0 0 6px}.dq ul{margin:0;padding-left:18px}.dq li{margin:3px 0;font-size:15px}
.opprow{margin:14px 0}.opphd{display:flex;flex-wrap:wrap;gap:8px;align-items:center}.wedgechip{font-size:12px;font-weight:700;padding:2px 10px;border-radius:99px;border:1px solid var(--pb)}.oppchip{}.defn{background:var(--tl);border-left:3px solid var(--co);border-radius:6px;padding:10px 14px;margin:8px 0 12px;font-size:14px}
.dl{display:inline-flex;flex-direction:column;gap:2px;background:var(--pb);color:#fff;text-decoration:none;padding:12px 18px;border-radius:8px;border-left:5px solid var(--co);margin:6px 0 4px}.dl b{font-size:16px}.dl span{font-size:12px;opacity:.8}.steps{padding-left:20px}.steps li{margin:10px 0}code{background:var(--nl);padding:2px 6px;border-radius:4px;font-size:13px;word-break:break-all}
.tchips{margin-top:6px}.tile .oppchip{display:inline-flex;font-size:11px;padding:1px 8px;margin-top:0}
.pool{border:1px solid var(--bd);border-top:3px solid var(--c);border-radius:8px;padding:14px;background:var(--wh)}.pool .core{font-size:30px;font-weight:700;color:var(--pb);line-height:1.1}.pool .corel{font-size:13px;color:var(--mu);margin-bottom:8px}.pool table{font-size:13px;margin:4px 0}.pool td{padding:5px 6px}.pool tbody tr:nth-child(even) td{background:transparent}
.caveat{background:var(--fw);border-left:3px solid var(--mu);border-radius:6px;padding:10px 14px;font-size:14px;margin:12px 0}
.stat4{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin:10px 0 16px}.stat4 div{background:var(--nl);border-radius:8px;padding:12px}.stat4 b{display:block;font-size:26px;color:var(--cod);line-height:1.1}.stat4 span{font-size:13px}
.insight{border-left:4px solid var(--c,var(--pb));background:var(--fw);border-radius:6px;padding:12px 14px;margin:10px 0}.insight h4{font-size:15px;margin:0 0 4px}
.events{list-style:none;padding:0;margin:10px 0}.events li{display:grid;grid-template-columns:34px 1fr;gap:10px;margin:10px 0}.events .n{width:26px;height:26px;border-radius:50%;background:var(--pb);color:#fff;font-weight:700;font-size:13px;display:flex;align-items:center;justify-content:center}
.bars div.bar{display:grid;grid-template-columns:220px 1fr 60px;gap:10px;align-items:center;font-size:14px;margin:6px 0}.bars .fill{height:12px;border-radius:6px;background:var(--c)}
.pat{border:1px solid var(--bd);border-left:4px solid var(--c,var(--mu));border-radius:8px;padding:12px 14px;margin:12px 0}.pat ul{margin:6px 0 0;padding-left:18px;font-size:14px}
.h2h{border:1px solid var(--bd);border-top:3px solid var(--c);border-radius:8px;padding:14px;background:var(--wh)}.h2h .vs{font-weight:700;font-size:17px;margin:6px 0 10px}.h2h .vs i{font-style:normal;color:var(--co);margin:0 8px}.h2h p{margin:6px 0;font-size:14px}.h2h .oppchip{white-space:normal}.trap{background:var(--tl);border-radius:6px;padding:8px 10px;font-size:14px}
.find{display:grid;grid-template-columns:160px 1fr;gap:12px;border-bottom:1px solid var(--bd);padding:10px 0;font-size:14px}
.opener{border-left:3px solid var(--co);background:var(--nl);padding:8px 10px;margin-top:8px;font-size:14px;font-style:italic}
.qs{border-top:6px solid var(--pb)}.qs-eyebrow{color:var(--co);font-weight:700;font-size:13px;letter-spacing:.08em;text-transform:uppercase;margin-bottom:6px}
.qs .g2{display:grid;grid-template-columns:repeat(auto-fit,minmax(340px,1fr));gap:20px}
.qs-h{display:flex;align-items:center;gap:10px;font-weight:700;font-size:18px;margin:18px 0 10px}.qs-h .num{display:inline-flex;align-items:center;justify-content:center;width:26px;height:26px;border-radius:50%;background:var(--pb);color:#fff;font-size:14px}
.qs .sig{background:var(--nl);border:0;border-radius:8px;padding:12px 14px;margin:0 0 12px}.qs .sig .l{font-weight:700;margin-bottom:6px}.qs .sig p{margin:0 0 8px}
.qs .small{color:var(--mu);font-size:12px}
.qs .focus{border:1px solid var(--bd);border-top:3px solid var(--c);border-radius:8px;padding:12px 14px;margin:0 0 12px}.qs .focus p{margin:4px 0}
.qs .check{border:1px solid var(--co);border-left:6px solid var(--co);background:var(--tl);border-radius:8px;padding:10px 14px;margin-top:10px}.qs .check .t{display:block;color:var(--cod);text-transform:uppercase;font-size:12px;letter-spacing:.06em;margin-bottom:4px;font-weight:700}
.qs .msg{border:1px solid var(--bd);border-radius:8px;padding:14px 16px;margin:12px 0;background:var(--wh)}.qs .msg .note{color:var(--mu);font-size:12px;margin:8px 0 0}
.qs ul{margin:4px 0 8px;padding-left:20px}.qs .box{border:1px solid var(--bd);border-radius:8px;padding:14px 16px;margin:12px 0}.qs .avoid{color:var(--cod);font-size:14px}
.qs .email{white-space:pre-wrap}
nav a.qsl{color:#fff;font-weight:700}
.locked{display:flex;flex-direction:column;gap:2px;margin:6px 0;font-size:13px;color:var(--mu)}.blur{filter:blur(4px);user-select:none;color:var(--pb)}
.stat4 .tchips{margin-top:6px}.stat4 .tt{display:block;font-weight:700;font-size:13px;color:var(--pb);margin-bottom:4px}.stat4 .tl{margin:6px 0 0;padding-left:16px;font-size:13px}.stat4 .tl li{margin:2px 0}.stat4 .oppchip{font-size:11px}
.g2c{display:grid;grid-template-columns:repeat(auto-fit,minmax(340px,1fr));gap:14px;align-items:start}.g2c>.email,.g2c>.sig,.g2c>.insight,.g2c>.opprow,.g2c>.newsgrp{margin:0}.status{font-weight:400}.status b{font-weight:700}
.tenure{font-size:13px;margin-top:2px}.bcpanel{background:var(--nl);border:1px solid var(--bd);border-left:6px solid var(--pb);border-radius:12px;padding:18px 20px;margin:16px 0 26px}.bcpanel table tbody tr:nth-child(even) td{background:var(--fw)}.bcpanel table td{background:var(--wh)}.bctag{display:inline-block;background:var(--pb);color:#fff;font-size:12px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;padding:3px 10px;border-radius:99px}.howpick{background:var(--wh);border-left:3px solid var(--co);border-radius:6px;padding:10px 14px;font-size:14px}.ctdiv{border-top:3px solid var(--pb);padding-top:6px;margin-top:10px}#talktrack{border:1px solid var(--bd);border-left:4px solid var(--co);border-radius:8px;padding:14px 16px;background:var(--wh)}#talktrack ul{margin:4px 0 8px;padding-left:20px}#talktrack .avoid{color:var(--cod);font-size:14px}.sendfirst{list-style:none;padding:0;margin:8px 0 0}.sendfirst li{margin:6px 0}.relbox{border:2px dashed var(--mu);border-radius:10px;padding:12px 16px;margin:14px 0 0;background:var(--fw)}.relbox ul{margin:0;padding-left:18px}
@media print{nav{display:none}body{background:#fff}section,.card,table,.sig,.contact,.email{break-inside:avoid}}
@media(max-width:700px){.quad{grid-template-columns:1fr}.hero h1{font-size:30px}}
"""

parts = []
add = parts.append

# ---------- Hero ----------
if brandlogo:
    toprow = f'<div class="toprow"><img class="secwm" src="data:image/png;base64,{brandlogo}" alt="{CUST}"><div class="poweredby"><span>Powered by</span><img src="data:image/png;base64,{logo}" alt="HG Insights"></div></div>'
    eyebrow = f'<div class="eyebrow"><span class="kicker">Account &amp; Contacts Intelligence</span> &middot; Account Win Plan for {CUST} sellers, prepared on {e(PREP_DATE)}</div>'
else:
    toprow = f'<div class="toprow"><img src="data:image/png;base64,{logo}" alt="HG Insights" style="height:30px;opacity:1"><span class="kicker">Account &amp; Contacts Intelligence</span></div>'
    eyebrow = f'<div class="eyebrow">Account Win Plan &middot; Prepared for {CUST} on {e(PREP_DATE)}</div>'
_smean = {"CURRENT": "uses the seller's product today", "LAPSED": "used the seller's product before, not seen in the last 12 months", "NET-NEW": "no seller product detected"}
status_chip = f'<span class="status"><b>Account status:</b> {e(M["account_status"].title())}, {e(M.get("status_short") or _smean.get(M["account_status"], ""))}</span><span class="statusnote">HG-detected, rep to confirm</span>'
if any(isinstance(t, dict) and t.get("label") == "Motion" for t in H["tags"]):
    status_chip = '<span class="statusnote">HG-detected, rep to confirm</span>'  # Motion already states the account status
tiles = "".join(
    f'<div class="tile"><b>{e(s["value"])}</b><span>{e(s["label"])}</span><em>{e(s["source"])}</em>{('<div class="tchips">' + chips(s.get("opp_ids")) + '</div>') if s.get("opp_ids") else ""}</div>'
    for s in H["stats"])
add(f"""<header class="hero"><div class="wrap">
{toprow}
{eyebrow}
<h1>{e(M["target_account"])}</h1>
<p class="sub">{e(H["one_liner"])}</p>
<div class="chips">{''.join(f'<span class="chip"><b>{e(t["label"])}:</b> {e(t["value"])}</span>' if isinstance(t, dict) else f'<span class="chip">{e(t)}</span>' for t in H["tags"])}{status_chip}</div>
<p class="prep">Featured product line: {e(M["product_line"])}</p>
<div class="tiles">{tiles}</div>
</div></header>""")

sample_note = ""
if show_byo:
    sample_note = f"""<aside class="dq" id="sample">
<h2>This sample win plan uses HG data only. Add {CUST}'s own data and it gets sharper.</h2>
<p>Everything in this win plan comes from HG Insights: installs, spend, intent, news and contacts. {"An" if CUST[:1].upper() in "AEIOU" else "A"} {CUST} seller gets all of it without anyone connecting a {CUST} system. The next step is to bring in what only {CUST} knows, so the plan shows HG's view of the market and {CUST}'s view of the relationship on one page.</p>
<div class="cols">
<div class="col"><h4>In this win plan (HG data)</h4><ul>
<li>The installs that matter at {e(M["target_account"])}, and since when</li>
<li>IT and relevant spend, and the share {CUST} can address</li>
<li>Buyer intent, news and the buying committee</li></ul></div>
<div class="col add"><h4>Add from {CUST} (first-party data)</h4><ul>
<li>CRM: open opportunities, account owner, last touch, closed-lost reasons</li>
<li>{CUST} product data: which {CUST} products the account already uses, plus usage and recent findings</li>
<li>Relationships: which {CUST} people already know these buyers</li></ul></div>
</div></aside>"""


nav_items = [("why", "Why Now"), ("opps", "Opps to Win"), ("spend", "Tech Spend"), ("signals", "Tech Signals"),
             ("intent", "Intent Signals"), ("news", "News Signals")] + ([("peers", "Peers Comparison")] if D.get("peers") else []) + [
             ("comp", "Competitive Battle Card"), ("contacts", "Contacts & Outreach Drafts"),
             ("sources", "Sources")] + ([("build", "Build Your Own Account Win Plan")] if show_byo else [])
add("<nav>" + ('<a class="qsl" href="#quickstart">&#9654; Quick Start</a>' if D.get("quick_start") else "") + "".join(f'<a href="#{i}"><b>&sect;{n+1}</b>{e(t)}</a>' for n, (i, t) in enumerate(nav_items)) + "</nav>")
add('<main class="wrap">')
SEC = {i: n + 1 for n, (i, _) in enumerate(nav_items)}
call = ""
Q = D.get("quick_start")
if Q:
    sigs = "".join(f'<div class="sig"><div class="l">{e(x["headline"])} {chips(x.get("opp_ids"))}</div><p>{e(x["detail"])}</p><p><b>So what:</b> {e(x["so_what"])}</p><div class="small">Source: {e(x["source"])}</div></div>' for x in Q["why_now"])
    foc = "".join(f'<div class="focus" style="--c:{OPP[f["opp_id"]][1]}"><b>{e(oname(f["opp_id"]))}</b><p><b>Contact first:</b> {e(f["contact"])}</p><p>{e(f["why"])}</p></div>' for f in Q["focus"])
    angles = "".join(f'<div class="msg">{named_chip(a["opp_id"])}<p style="margin:8px 0 0"><i>&ldquo;{e(a["question"])}&rdquo;</i></p></div>' for a in Q["angles"])
    ct = Q["call"]
    call = (f'<div class="box" id="talktrack"><b>Call talk track</b> {chips(ct.get("opp_ids"))}<p><b>Opener:</b> {e(ct["opener"])}</p><p><b>If it&rsquo;s them, ask:</b></p><ul>' + "".join(f'<li>{e(q)}</li>' for q in ct["questions"]) + f'</ul><p><b>The ask:</b> {e(ct["ask"])}</p><p class="avoid"><b>Avoid:</b> {e(ct["avoid"])}</p></div>')
    mails = "".join(f'<div class="email"><div class="hd">{named_chip(m["opp_id"])}<br>To: {e(m["to"])}<br>Subject: {e(m["subject"])}</div><hr style="border:0;border-top:1px solid #CED1D6;margin:8px 0">{e(m["body"])}</div>' for m in Q.get("emails", []))
    _cid = (ct.get("opp_ids") or [None])[0]
    _cwho = next((f["contact"].split(",")[0] for f in Q["focus"] if f["opp_id"] == _cid), "")
    _call_li = f'<li>{chips(ct.get("opp_ids"))} <b>{e(_cwho) or "Lead contact"}</b>: <a href="#talktrack">Call, using the talk track</a></li>'
    add(f"""<section id="quickstart" class="qs"><div class="qs-eyebrow">60-second read &middot; quick start</div>
<h2>{e(M.get("target_short", M["target_account"]))} in one minute</h2>
<p class="take">{e(Q["summary"])}</p>
<div class="g2"><div><div class="qs-h"><span class="num">1</span>Why now</div>{sigs}
<p><b>{CUST} customer status:</b> {e(Q["status"])}</p><p><b>Competition:</b> {e(Q["competition"])}</p></div>
<div><div class="qs-h"><span class="num">2</span>Where to focus</div>{foc}
{('<div class="check"><span class="t">Check first</span>' + e(Q["check_first"]) + '</div>') if Q.get("check_first") else ""}
<div class="qs-h"><span class="num">3</span>Suggested messaging angle</div>
<p>{e(Q["angle_intro"])}</p>{angles}<p class="small">These are sample messaging angles. Please adjust as needed.</p>
{('<div class="box" style="margin-top:12px"><b>Call or send first</b><ul class="sendfirst">' + _call_li + "".join(f'<li>{chips(m.get("opp_ids"))} <b>{e(m["to"].split(",")[0])}</b>: <a href="#email-{n}">Email, &ldquo;{e(m["subject"])}&rdquo;</a></li>' for n, m in enumerate(D["outreach"])) + '</ul><p class="small" style="margin:6px 0 0">The talk track and full email drafts are in <a href="#outreach">&sect;' + str(SEC["contacts"]) + ' Contacts &amp; Outreach Drafts</a>.</p></div>') if D.get("outreach") else ""}
</div></div>
<p class="take" style="margin-top:16px">The rest of this win plan goes into detail to help you earn {e(M.get("target_short", M["target_account"]))}&rsquo;s business.</p></section>""")

# ---------- 1 Why now ----------
W = D["why_now"]
if len(W["paragraphs"]) != 3:
    sys.exit(f"why_now.paragraphs must be the takeaway plus exactly 2 paragraphs; got {len(W['paragraphs'])} strings. Fix the JSON in the research step.")
mx = W.get("matrix") or {}
hot = {"Displacement": "competitor_installed_own_intent", "Expansion": "own_installed_own_intent",
       "Churn risk": "own_installed_competitor_intent", "Competitor entrenched": "competitor_installed_competitor_intent"}.get(M.get("quadrant"), "")
def qcell(key, label):
    cls = "qc hot" if key == hot else "qc"
    return f'<div class="{cls}"><b>{label}</b>{"<br>".join(e(x) for x in mx[key])}</div>'
matrix_html = ""
if W.get("show_matrix") and mx:  # optional graphic, off by default
    matrix_html = f"""<h3>Installs x intent</h3>
<div class="quad">
<div class="qh"></div><div class="qh">Intent on {CUST} products</div><div class="qh">Intent on competitor products</div>
<div class="qh">{CUST} product installed</div>{qcell("own_installed_own_intent","Expansion")}{qcell("own_installed_competitor_intent","Churn risk")}
<div class="qh">Competitor product installed</div>{qcell("competitor_installed_own_intent","Displacement")}{qcell("competitor_installed_competitor_intent","Competitor entrenched")}
</div>
<div class="strip"><b>Whitespace:</b> {"; ".join(e(x) for x in mx.get("whitespace", []))}</div>"""
_rel_default = {"LAPSED": ["What they bought, what they paid and when the contract ended", "Why they left, in their words", "Who championed you, and where they are now", "How they used it, and what worked"],
                "CURRENT": ["Products owned, contract value and renewal date", "Usage and health", "Your champion and executive sponsor", "Open opportunities and support issues"],
                "NET-NEW": ["Any past touches, meetings or closed-lost reasons", "Who in your company knows people there", "Open opportunities"]}
_rp = W.get("relationship_prompts") or _rel_default.get(M["account_status"], [])
rel_html = ""
if _rp:
    rel_html = (f'<div class="relbox"><b>Your relationship with {e(M.get("target_short", M["target_account"]))}: add from your CRM</b>'
                f'<p class="meta" style="margin:4px 0 6px">HG data cannot see your own history with this account. Check these before the first call:</p><ul>'
                + "".join(f'<li>{e(x)}</li>' for x in _rp) + '</ul></div>')
add(f"""<section id="why"><h2>&sect;{SEC["why"]} Why now: {e(M.get("target_short", M["target_account"]))}</h2>
<p class="take">{e(W["paragraphs"][0])}</p>
{"".join(para(x) for x in W["paragraphs"][1:])}
{matrix_html}{rel_html}</section>""")

# ---------- 2 Opportunities ----------
O = D["opportunities"]
if not 1 <= len(O["items"]) <= 3:
    sys.exit(f"opportunities.items must hold 1 to 3 opportunities; got {len(O['items'])}. Fix the JSON in the research step.")
tier_cls = {"Near": ("p1", "Priority 1, near term"), "Mid": ("p2", "Priority 2, mid term"), "Long": ("p3", "Priority 3, long term")}
rows = ""
for n, i in enumerate(O["items"]):
    m = next(x for x in O["matrix"] if x["opp_id"] == i["id"])
    w = (O.get("wedge") or [{}] * 3)[n] if n < len(O.get("wedge") or []) else {}
    cls, lab = tier_cls[m["tier"]]
    rows += (f'<div class="card opprow" style="--c:{OPP[i["id"]][1]}"><div class="opphd"><span class="pchip {cls}">{lab}</span>{('<span class="wedgechip">Wedge: ' + e(w["phase"]) + "</span>") if w.get("phase") else ""}</div>'
             f'<h4>{e(oname(i["id"]))}</h4><p>{e(i["body"])}</p>'
             f'<p class="meta"><b>Why this priority:</b> {e(m["rationale"])} <b>Entry timeline:</b> {e(m["timeline"])}</p>'
             + (f'<p class="meta"><b>Wedge step:</b> {e(w["body"])}</p>' if w.get("body") else "") + '</div>')
add(f"""<section id="opps"><h2>&sect;{SEC["opps"]} Opps to win</h2>
<p class="take">{tk("opps","Each opportunity ties a detected signal to what the seller offers here.")}</p>
<div class="g2c">{rows}</div>
<p class="src">Synthesis of the HG signals in the sections below. Opportunity framing is a read, not an HG data point.</p>
</section>""")

# ---------- 3 Tech spend ----------
T = D["tech_spend"]
cards = ""
for oid in opp_names:  # only the opportunities in the plan (1 to 3)
    label, color = OPP[oid]
    rows = [r for r in T["rows"] if r["opp_id"] == oid]
    lines = "".join(f'<li>{e(r["category"])}: <b>{e(r["amount"])}</b>{" (addressable)" if r["addressable"] else " (context)"}</li>' for r in rows) or "<li>No HG spend line maps directly to this opportunity.</li>"
    addr = [r for r in rows if r["addressable"]]
    addr_txt = ", ".join(f'{r["amount"]}' for r in addr) if addr else "none counted"
    cards += f'<div class="card" style="--c:{color}"><h4>{e(oname(oid))}</h4><ul style="padding-left:18px;margin:6px 0">{lines}</ul><p class="meta">Directly addressable: {e(addr_txt)}</p></div>'
ai_spend_html = ""
if T.get("ai_rows"):
    _ar = "".join(f'<tr class="{"total" if r.get("total") else ""}"><td>{"&nbsp;&nbsp;&#8627; " if r.get("child") else ""}{e(r["category"])}</td><td>{e(r["amount"])}</td><td>{chips(r.get("opp_ids"))}</td><td>{e(r.get("note",""))}</td></tr>' for r in T["ai_rows"])
    ai_spend_html = f'<tr><td colspan="4" style="background:var(--pb);color:#fff;font-weight:700">AI spend (part of Total IT above; do not add)</td></tr>{_ar}'
if T.get("pools"):
    cards = ""
    for pl in T["pools"]:
        lns = "".join(f'<tr><td>{e(x["label"])}</td><td style="text-align:right"><b>{e(x["amount"])}</b></td></tr>' for x in pl.get("lines", []))
        cav = f'<p class="meta">{e(pl["caveat"])}</p>' if pl.get("caveat") else ""
        cards += f'<div class="pool" style="--c:{OPP[pl["opp_id"]][1]}"><h4>{e(oname(pl["opp_id"]))}</h4><div class="corel">Core pool &middot; {e(pl["core_label"])}</div><div class="core">{e(pl["core_amount"])}</div><table>{lns}</table>{cav}</div>'
trs = ""
for r in T["rows"]:
    cls = ""
    if r["category"].startswith("Total IT"):
        cls = "total"
    if r["addressable"]:
        cls = "addr"
    badge = '<span class="badge">Addressable</span>' if r["addressable"] else ""
    trs += f'<tr class="{cls}"><td>{e(r["category"])}{badge}</td><td>{e(r["amount"])}</td><td>{chip(r["opp_id"])}</td><td>{e(r["note"])}</td></tr>'
add(f"""<section id="spend"><h2>&sect;{SEC["spend"]} Tech spend</h2>
<p class="take">{tk("spend", "Directly addressable: " + T["directly_addressable"] + " of a " + T["total_it_budget"] + " IT budget.")}</p>
<h3>Spend pools by opportunity</h3><div class="grid3">{cards}</div>
{('<div class="caveat"><b>Do not add the pools together.</b> ' + e(T["overlap_note"]) + '</div>') if T.get("overlap_note") else ""}
{('<div class="caveat"><b>Not all of it is open to ' + CUST + '.</b> ' + e(T["not_addressable_note"]) + '</div>') if T.get("not_addressable_note") else ""}
<h3>Projected IT Spend</h3>{('<p class="meta" style="margin-top:0">' + e(T["ai_note"]) + '</p>') if T.get("ai_note") else ""}
<table><thead><tr><th>Category</th><th>Estimate</th><th>Opportunity</th><th>Relevance</th></tr></thead><tbody>{trs}{ai_spend_html}</tbody></table>
{src(T["source"])}</section>""")

# ---------- 4 Tech signals ----------
S = D["tech_signals"]
trs = ""
_mx = max([r["intensity"] or 0 for r in S["installs"]] or [1]) or 1
def use_level(v):
    v = v or 0
    return "Heavy" if v >= 0.5 * _mx else ("Moderate" if v >= 0.15 * _mx else "Light")
for r in S["installs"]:
    dep = "" if S.get("teams") else f'<td>{e(r["departments"])}</td>'
    trs += f'<tr><td>{e(r["product"])}</td><td>{e(r["vendor"])}</td><td>{e(r["deployment"])}</td>{dep}<td>{use_level(r["intensity"])}</td><td>{chip(r["opp_id"])}</td></tr>'

def trend_svg(series_list, title):
    W_, H_ = 760, 370
    L, R, Tp, Bm = 60, 20, 20, 140
    pw, ph = W_ - L - R, H_ - Tp - Bm
    allv = [p["intensity"] for sr in series_list for p in sr["points"] if p["intensity"] is not None]
    ymax = max(4, max(allv))
    pts0 = series_list[0]["points"]
    n = len(pts0)
    xs = [L + pw * i / (n - 1) for i in range(n)]
    out = [f'<svg viewBox="0 0 {W_} {H_}" width="100%" role="img" aria-label="{e(title)}" style="font-family:{B["font"].replace(chr(34), "")}">']
    for t in range(0, ymax + 1):
        y = Tp + ph - ph * t / ymax
        out.append(f'<line x1="{L}" y1="{y:.1f}" x2="{W_-R}" y2="{y:.1f}" stroke="{B["bd"]}"/>')
        out.append(f'<text x="{L-8}" y="{y+4:.1f}" font-size="12" fill="{B["mu"]}" text-anchor="end">{t}</text>')
    out.append(f'<line x1="{L}" y1="{Tp}" x2="{L}" y2="{Tp+ph}" stroke="{B["bd"]}"/>')
    for i, p in enumerate(pts0):
        if i % 2 == 0 or i == n - 1:
            out.append(f'<text x="{xs[i]:.1f}" y="{Tp+ph+16}" font-size="11" fill="{B["mu"]}" text-anchor="end" transform="rotate(-45 {xs[i]:.1f} {Tp+ph+16})">{e(p["period"])}</text>')
    lx = L
    row = 0
    for sr in series_list:
        itemw = 32 + 7.2 * len(sr['name']) + 22
        if lx + itemw > W_ - R and lx > L:
            lx = L
            row += 1
        ly = H_ - 56 + row * 20
        color = OPP.get(sr.get("opp_id"), ("", B["opp"][0]))[1]
        dash = ' stroke-dasharray="6 4"' if sr.get("dash") else ""
        pts = sr["points"]
        for i in range(n - 1):
            if pts[i]["intensity"] is not None and pts[i+1]["intensity"] is not None:
                y1 = Tp + ph - ph * pts[i]["intensity"] / ymax
                y2 = Tp + ph - ph * pts[i+1]["intensity"] / ymax
                out.append(f'<line x1="{xs[i]:.1f}" y1="{y1:.1f}" x2="{xs[i+1]:.1f}" y2="{y2:.1f}" stroke="{color}" stroke-width="2"{dash}/>')
        for i, p in enumerate(pts):
            if p["intensity"] is not None:
                y = Tp + ph - ph * p["intensity"] / ymax
                fill = "#fff" if sr.get("dash") else color
                out.append(f'<circle cx="{xs[i]:.1f}" cy="{y:.1f}" r="5" fill="{fill}" stroke="{color}" stroke-width="2"/>')
        out.append(f'<line x1="{lx}" y1="{ly}" x2="{lx+26}" y2="{ly}" stroke="{color}" stroke-width="2"{dash}/><circle cx="{lx+13}" cy="{ly}" r="4" fill="{"#fff" if sr.get("dash") else color}" stroke="{color}" stroke-width="2"/>')
        out.append(f'<text x="{lx+32}" y="{ly+4}" font-size="12" fill="{B["pb"]}">{e(sr["name"])}</text>')
        lx += itemw
    out.append(f'<text x="{L+pw/2}" y="{H_-8}" font-size="12" fill="{B["mu"]}" text-anchor="middle">Month (the latest month is incomplete and left out)</text>')
    out.append(f'<text x="14" y="{Tp+ph/2}" font-size="12" fill="{B["mu"]}" text-anchor="middle" transform="rotate(-90 14 {Tp+ph/2})">Days detected in the month</text>')
    out.append("</svg>")
    return "".join(out)

tr = S.get("install_trend")
bc = "".join(f'<div><div class="big">{e(b["figure"])}</div><h4 style="margin:6px 0">{e(b["heading"])}</h4><div>{chips(b.get("opp_ids"))}</div><p>{e(b["body"])}</p></div>' for b in S.get("buying_centers", []))
trend_html = ""
defn_html = f'<p class="defn"><b>Use level:</b> {e(S.get("intensity_definition") or (tr or {}).get("definition") or "")}</p>' if (S.get("intensity_definition") or (tr or {}).get("definition")) else ""
if tr and tr.get("series") and any(sum(1 for p in sr["points"] if p["intensity"] is not None) >= 4 for sr in tr["series"]):
    miss = f'<p class="src">{" ".join(e(m) for m in tr.get("missing", []))}</p>' if tr.get("missing") else ""
    trend_html = f'<h3>Install trend</h3><p class="take">{e(tr["takeaway"])}</p>{trend_svg(tr["series"], "Monthly detection days for the main installs at the target account")}<p class="meta">{e(tr.get("note", ""))}</p>{miss}'
def story_svg(st):
    W_, H_ = 760, 330
    L, R, Tp, Bm = 54, 20, 20, 96
    pw, ph = W_ - L - R, H_ - Tp - Bm
    periods = st["periods"]; n = len(periods)
    allv = [v for sr in st["series"] for v in sr["values"] if v is not None]
    ymax = max(4, max(allv)); step = max(1, round(ymax / 5))
    xs = [L + pw * i / (n - 1) for i in range(n)]
    Y = lambda v: Tp + ph - ph * v / ymax
    out = [f'<svg viewBox="0 0 {W_} {H_}" width="100%" role="img" aria-label="{e(st["title"])}" style="font-family:{B["font"].replace(chr(34), "")}">']
    for band in st.get("bands", []):
        i0, i1 = periods.index(band["from"]), periods.index(band["to"])
        x0 = xs[i0] - (pw / (n - 1)) / 2; x1 = xs[i1] + (pw / (n - 1)) / 2
        out.append(f'<rect x="{x0:.1f}" y="{Tp}" width="{x1-x0:.1f}" height="{ph}" fill="{B["tl"]}" opacity=".55"/>')
    t = 0
    while t <= ymax:
        out.append(f'<line x1="{L}" y1="{Y(t):.1f}" x2="{W_-R}" y2="{Y(t):.1f}" stroke="{B["bd"]}"/><text x="{L-8}" y="{Y(t)+4:.1f}" font-size="12" fill="{B["mu"]}" text-anchor="end">{t}</text>')
        t += step
    for i, p in enumerate(periods):
        if i % 3 == 0 or i == n - 1:
            out.append(f'<text x="{xs[i]:.1f}" y="{Tp+ph+16}" font-size="11" fill="{B["mu"]}" text-anchor="end" transform="rotate(-40 {xs[i]:.1f} {Tp+ph+16})">{e(p)}</text>')
    lx = L
    for sr in st["series"]:
        color = OPP[sr["opp_id"]][1] if sr.get("opp_id") in OPP else B["mu"]; vals = sr["values"]
        for i in range(n - 1):
            if vals[i] is not None and vals[i+1] is not None:
                out.append(f'<line x1="{xs[i]:.1f}" y1="{Y(vals[i]):.1f}" x2="{xs[i+1]:.1f}" y2="{Y(vals[i+1]):.1f}" stroke="{color}" stroke-width="2.5"/>')
        for i, v in enumerate(vals):
            if v is not None:
                out.append(f'<circle cx="{xs[i]:.1f}" cy="{Y(v):.1f}" r="3.5" fill="{color}"/>')
        ly = H_ - 14
        out.append(f'<line x1="{lx}" y1="{ly}" x2="{lx+24}" y2="{ly}" stroke="{color}" stroke-width="3"/><text x="{lx+30}" y="{ly+4}" font-size="12" fill="{B["pb"]}">{e(sr["name"])}</text>')
        lx += 40 + 7 * len(sr["name"])
    for a in st.get("markers", []):
        i = periods.index(a["period"])
        out.append(f'<line x1="{xs[i]:.1f}" y1="{Tp}" x2="{xs[i]:.1f}" y2="{Tp+ph}" stroke="{B["pb"]}" stroke-dasharray="3 3"/><circle cx="{xs[i]:.1f}" cy="{Tp+10}" r="10" fill="{B["pb"]}"/><text x="{xs[i]:.1f}" y="{Tp+14}" font-size="11" font-weight="700" fill="#fff" text-anchor="middle">{e(a["n"])}</text>')
    out.append(f'<text x="14" y="{Tp+ph/2}" font-size="12" fill="{B["mu"]}" text-anchor="middle" transform="rotate(-90 14 {Tp+ph/2})">{e(st.get("y_label","Days detected in the month"))}</text></svg>')
    return "".join(out)

story_html = ""
ST = S.get("trend_story")
if ST:
    ev = "".join(f'<li><span class="n">{e(x["n"])}</span><div><b>{e(x["date"])}:</b> {e(x["body"])} {chips(x.get("opp_ids"))}</div></li>' for x in ST.get("events", []))
    story_html = f'<h3>Install trend</h3>{story_svg(ST)}<h4 style="margin:14px 0 2px">What the numbered markers show</h4><p class="meta" style="margin:0">Each number marks a dated change on the chart above; read them in order to see how {e(M.get("target_short", M["target_account"]))}&rsquo;s tool stack shifted.</p><ol class="events">{ev}</ol><p class="meta">{e(ST.get("note",""))}</p>'

ai_mat_html = ""
AM = S.get("ai_maturity")
if AM:
    _t = "".join(f'<div><span class="tt">{e(x["title"])}</span><b>{e(x["value"])}</b><span>{e(x.get("detail",""))}</span>'
                 + (('<ul class="tl">' + "".join(f'<li>{e(i)}</li>' for i in x["list"]) + '</ul>') if x.get("list") else "")
                 + (("<div class=tchips>" + chips(x.get("opp_ids")) + "</div>") if x.get("opp_ids") else "") + '</div>' for x in AM["tiles"])
    ai_mat_html = f'<h3>AI maturity</h3><div class="stat4">{_t}</div><div class="insight" style="--c:{OPP[(AM.get("opp_ids") or ["opp1"])[0]][1]}"><h4>What it means {chips(AM.get("opp_ids"))}</h4><p style="margin:0">{e(AM["meaning"])}</p></div><p class="meta">{e(AM.get("note",""))}</p>'
teams_html = ""
TM = S.get("teams")
if TM:
    ins = "".join(f'<div class="insight" style="--c:{OPP[(x.get("opp_ids") or ["opp1"])[0]][1]}"><h4>{e(x["heading"])} {chips(x.get("opp_ids"))}</h4><p style="margin:0">{e(x["body"])}</p></div>' for x in TM.get("insights", []))
    trs2 = "".join(f'<tr><td><b>{e(r["technology"])}</b><div>{chips(r.get("opp_ids"))}</div></td><td>{e(r.get("departments",""))}</td><td>{e(r["locations"])}</td><td>{e(r.get("contacts") or r.get("influencers",""))}</td></tr>' for r in TM.get("rows", []))
    teams_html = (f'<div class="bcpanel"><div class="bctag">Buying Centers</div><h3 style="margin-top:4px">Where the teams sit, and who decides</h3>'
                  f'<p class="howpick"><b>How HG picks the contacts below:</b> HG Insights Buying Centers (HG&rsquo;s Functional Area Intelligence) show which departments, roles and locations use each product most. HG then picks contacts whose titles and locations match those teams, so you reach the people closest to where the products are actually used.</p>'
                  f'<p class="take">{e(TM["takeaway"])}</p>'
                  f'<table><thead><tr><th>Technology and opportunity</th><th>Departments</th><th>Lead locations</th><th>Likely contacts (matched by title; confirm)</th></tr></thead><tbody>{trs2}</tbody></table><div class="g2c">{ins}</div>'
                  f'<p class="meta">{e(TM.get("note",""))}</p></div>')

add(f"""<section id="signals"><h2>&sect;{SEC["signals"]} Tech signals{"" if TM else " and Buying Centers"}</h2>
<p class="take">{tk("signals","The installs that matter for each opportunity, with the teams that use them.")}</p>
<table><thead><tr><th>Product</th><th>Vendor</th><th>Installed (first to last verified)</th>{"" if S.get("teams") else "<th>Departments</th>"}<th>Use level</th><th>Opportunity</th></tr></thead><tbody>{trs}</tbody></table>
{defn_html}
{story_html}{trend_html}
{ai_mat_html}{"" if TM else '<h3>Buying Centers</h3><div class="callouts">' + bc + '</div>'}
{src(S["source"])}</section>""")

# ---------- 5 Intent ----------
I = D["intent"]
order = {"Comparison": 0, "Pricing": 1, "Reviews and Ratings": 2, "Product Listing": 3, None: 4}
cards = sorted(I["cards"], key=lambda c: (0 if c["confidence"] == "Bidstream" else 1, order.get(c["page_type"], 4)))
ic = ""
first_tr = True
for c in cards:
    tcls = "disp" if c["context_type"] == "Displacement" else "comp"
    conf = "Contextual Intent (bidstream)" if c["confidence"] == "Bidstream" else "TrustRadius buyer intent"
    page = f'<span class="tag">{e(c["page_type"])}</span>' if c["page_type"] else ""
    comp = f'<span class="tag">Compared: {", ".join(e(p) for p in c["products_compared"])}</span>' if c["products_compared"] else ""
    score = (f'<span class="tag">{"Strong" if c["score"] >= 85 else "Moderate"} signal{", " + e(c["trend"]) if c.get("trend") else ""}</span>') if c["score"] is not None else '<span class="tag">Unscored activity</span>'
    link = f' <a href="{e(c["url"])}">TrustRadius page</a>' if c["url"] else ""
    ic += f'<div class="sig {tcls}"><span class="tag {tcls}">{e(c["context_type"])}</span><span class="tag">{conf}</span>{page}{comp}{score}<span class="tag">Last seen {e(c["last_seen"])}</span>{chips(c.get("opp_id"))}<h4 style="font-size:16px;margin:4px 0">{e(c["topic"])}</h4><p style="margin:4px 0">{e(c["meaning"])}{link}</p></div>'
tr_html = ""
TP = I.get("tr_patterns")
if TP:
    pats = ""
    for pt in TP.get("patterns", []):
        acts = "".join(f'<li>{e(a["date"])} &middot; {e(a["label"])}: {e(a["products"])}</li>' for a in pt["activities"])
        pats += f'<div class="pat" style="--c:{OPP[(pt.get("opp_ids") or ["opp1"])[0]][1]}"><b>{e(pt["title"])}</b> {chips(pt.get("opp_ids"))}<div class="meta">{e(pt["window"])} &middot; {e(pt["counts"])}</div><ul>{acts}</ul><p style="margin:8px 0 0">&#8627; {e(pt["meaning"])}</p></div>'
    tr_html = f'<h3>TrustRadius buyer intent patterns</h3>{pats or "<p>No relevant TrustRadius intent.</p>"}' + (f'<div class="caveat"><b>Pattern summary.</b> {e(TP["summary"])}</div>' if TP.get("summary") else "")
else:
    tr_html = '<h3>TrustRadius buyer intent patterns</h3><p>No relevant TrustRadius intent.</p>'
sc = "".join(f'<li>{chips(s.get("opp_id"))} {e(s["topic"])}: {e(s["note"])}</li>' for s in I["supporting_context"])
add(f"""<section id="intent"><h2>&sect;{SEC["intent"]} Intent signals</h2>
<p class="take">{tk("intent","HIGH-score intent only, with TrustRadius shown as activity.")}</p>
{para(I["so_what"]) if I.get("so_what") else ""}
<p class="meta">{e(I["scope_note"])}</p>
{('<h3>Contextual Intent activity patterns (bidstream)</h3><p class="meta" style="margin-top:0">Topics people at the account are researching across the web. Directional; it corroborates, it does not prove a purchase.</p><div class="g2c">' + ic + '</div>') if ic else ""}
{tr_html}
<h3>Supporting context: moderate Contextual Intent (not used to place the account)</h3><ul>{sc}</ul>
<p class="src">Source: HG Insights Intent and TrustRadius activity, {e(M["target_domain"])}, {PULL_MONTH}. TrustRadius intent is product research activity on TrustRadius; bidstream is directional.</p>
</section>""")

# ---------- 6 News ----------
ng = ""
for g in D["news"]:
    color = OPP[g["opp_id"]][1]
    its = "".join(f'<div class="newsitem"><a href="{e(i["url"])}"><b>{e(i["headline"])}</b></a><div class="meta">{e(i["source"])} &middot; {e(i["date"])}</div><div>{e(i["why"])}</div></div>' for i in g["items"]) if not g["none_found"] else "<p>No recent items found.</p>"
    ng += f'<div class="newsgrp" style="--c:{color}">{named_chip(g["opp_id"])}{its}</div>'
add(f"""<section id="news"><h2>&sect;{SEC["news"]} News signals</h2>
<p class="take">{tk("news","Here is the relevant news to know about in your conversations with people at " + M.get("target_short", M["target_account"]) + ".")}</p>
<div class="g2c">{ng}</div><p class="src">Source: web search, last 12 months where dated. Each outlet is cited per item.</p></section>""")

# ---------- Peers (optional) ----------
P = D.get("peers")
if P:
    hd = "".join(f'<th>{e(c)}</th>' for c in P["columns"])
    prow = "".join(f'<tr><td><b>{e(r["metric"])}</b> {chips(r.get("opp_ids"))}</td>' + "".join(f'<td>{e(v)}</td>' for v in r["values"]) + '</tr>' for r in P["rows"])
    pins = "".join(f'<div class="insight" style="--c:{OPP[(x.get("opp_ids") or ["opp1"])[0]][1]}"><h4>{e(x["heading"])} {chips(x.get("opp_ids"))}</h4><p style="margin:0">{e(x["body"])}</p></div>' for x in P.get("insights", []))
    add(f"""<section id="peers"><h2>&sect;{SEC["peers"]} Peers comparison</h2>
<p class="take">{e(P["takeaway"])}</p>
<table><thead><tr><th>Metric</th>{hd}</tr></thead><tbody>{prow}</tbody></table>
<p class="meta">{e(P.get("note",""))}</p><div class="g2c">{pins}</div>
{src(P["source"])}</section>""")

# ---------- 7 Competitive ----------
C = D["competitive"]
plays = C["landscape"]["plays"]
cls_map = {"Primary Threat": "t-p", "Active": "t-a", "Watch": "t-w", "Not a factor": "t-n"}
hrows = ""
for r in C["landscape"]["rows"]:
    cells = "".join(f'<td class="cell {cls_map[t]}">{e(t)}</td>' for t in (r.get("threat_by_opp") or r["threat_by_play"]))
    hrows += f'<tr><td><b>{e(r["vendor"])}</b><div class="meta">{e(r["signal"])}</div></td>{cells}</tr>'
h2h_html = ""
if C.get("head_to_head"):
    hh = "".join(f'<div class="h2h" style="--c:{OPP[x["opp_id"]][1]}">{named_chip(x["opp_id"])}<div class="vs">{e(x["us"])}<i>vs</i>{e(x["them"])}</div>{('<p><b>At ' + e(M.get("target_short", M["target_account"])) + ':</b> ' + e(x["at_account"]) + '</p>') if x.get("at_account") else ""}<p><b>Their angle:</b> {e(x["their_angle"])}</p><p><b>Our counter:</b> {e(x["our_counter"])}</p><p class="trap"><b>Trap question:</b> &ldquo;{e(x["trap_question"])}&rdquo;</p></div>' for x in C["head_to_head"])
    h2h_html = f'<h3>Head to head, by opportunity</h3><div class="grid3">{hh}</div>'
if C.get("findings") and not C.get("head_to_head"):
    h2h_html += '<h3>Finding and implication, by competitor</h3>' + "".join(f'<div class="find"><div><b>{e(x["vendor"])}</b><div>{chips(x.get("opp_ids"))}</div></div><div><b>Finding:</b> {e(x["finding"])}<br><b>Implication:</b> {e(x["implication"])}</div></div>' for x in C["findings"])
quotes = "".join(f'<blockquote>{e(q["text"])}<div class="meta">{e(q["reviewer"] or "TrustRadius review")}</div></blockquote>' for q in C["quotes"]) or '<p>No HG data available for customer review quotes matching this account (see Sources).</p>'
add(f"""<section id="comp"><h2>&sect;{SEC["comp"]} Competitive battle card</h2>
<p class="take">{tk("competitive","Who else is in the account and how much of a threat each is to each opportunity.")}</p>
<table class="heat"><thead><tr><th>Vendor and HG signal</th>{''.join(f'<th>{e(oname(o)) if o in opp_names else e(plays[n])}</th>' for n, o in enumerate(C["landscape"].get("opp_ids") or C["landscape"].get("play_opps") or [None]*len(plays)))}</tr></thead><tbody>{hrows}</tbody></table>
<p class="legend">Columns are the opportunities. <b>Primary Threat</b>: most likely to cost you the deal. <b>Active</b>: a real risk to this opportunity now. <b>Watch</b>: could become a risk. <b>Not a factor</b>: no effect on this opportunity.</p>
{h2h_html}
{('<h3>What HG data reveals</h3><p>' + e(C["hg_reveals"]) + '</p>') if C.get("hg_reveals") else ""}
{('<h3>What their customers say</h3>' + quotes) if C.get("quotes") else '<p class="meta">No TrustRadius review quotes matched this account&rsquo;s industry and size.</p>'}
{('<h3>Your angle for ' + e(M.get("target_short", M["target_account"])) + '</h3><p>' + e(C["angle"]) + '</p>') if C.get("angle") else ""}
<p class="src">Source: HG Insights Technographics, {e(M["target_domain"])}, {PULL_MONTH}.</p></section>""")

# ---------- 8 Contacts ----------
cg = ""
for g in D["contacts"]["groups"]:
    ppl = "".join(f'<div class="contact"><h4>{e(p["name"])}</h4><div>{e(p["title"])}</div><div class="meta">{e(p["location"])}</div>{('<div class="tenure"><b>At ' + e(M.get("target_short", M["target_account"])) + ':</b> ' + e(p["tenure"]) + '</div>') if p.get("tenure") else ""}{('<div class="meta">Source: ' + e(p["public_source"]) + '</div>') if p.get("public_source") else ('<div class="locked"><span>Email: <span class="blur" aria-hidden="true">name.surname@' + e(M["target_domain"]) + '</span></span><span>Mobile: <span class="blur" aria-hidden="true">+1 (555) 555-0100</span></span></div>')}<p style="margin:6px 0 0">{chips(p.get("opp_ids"))}<br><b>Angle:</b> {e(p["angle"])}</p>{('<div class="opener">&ldquo;' + e(p["opening_line"]) + '&rdquo;</div>') if p.get("opening_line") else ""}</div>' for p in g["people"])
    cg += f'<h3>{e(g["role"])}</h3><div class="grid3">{ppl}</div>'
contacts_html = f"""<p class="take">{e(D["contacts"]["lead_with"])}</p>{teams_html}<div class="ctdiv"><h3>Contacts</h3>{('<p class="meta" style="margin-top:0">Chosen to match the Buying Centers above, then grouped by role in the deal. Executive sponsors come from public sources.</p>') if TM else ""}</div>{"" if INTERNAL else '<div class="caveat"><b>Email addresses and mobile numbers are hidden.</b> HG provides them once ' + CUST + ' signs a data processing agreement (DPA).</div>'}{cg}
<p class="src">Source: HG Insights Contacts{" and Buying Centers" if TM else ""}, {e(M["target_domain"])}, {PULL_MONTH}.</p>"""

# ---------- 9 Outreach ----------
em = "".join(f'<div class="email" id="email-{n}"><div class="hd">{chips(m.get("opp_ids"))}<br>To: {e(m["to"])}<br>From: {e(m["from"])}<br>Subject: {e(m["subject"])}</div><hr style="border:0;border-top:1px solid #CED1D6;margin:8px 0">{e(m["body"])}</div>' for n, m in enumerate(D["outreach"]))
add(f"""<section id="contacts"><h2>&sect;{SEC["contacts"]} Contacts and outreach drafts</h2>
{contacts_html}
<h3 id="outreach">Outreach drafts</h3>
<p class="take">{tk("outreach","Short emails, one per lead contact, each built on the strongest signal for that person.")}</p>{call}<div class="g2c" style="margin-top:12px">{em}</div></section>""")

# ---------- 10 Sources ----------
Sx = D["sources"]
rows = "".join(f'<tr><td>{e(r["section"])}</td><td>{e(r["tool"])}</td><td>{chips(r.get("opp_ids"))}</td></tr>' for r in Sx["rows"])
add(f"""<section id="sources"><h2>&sect;{SEC["sources"]} Sources</h2>
<table><thead><tr><th>Section</th><th>Source</th><th>Supports</th></tr></thead><tbody>{rows}</tbody></table>
<p>Pull date: {e(Sx["pull_date"])} &middot; Frozen list: {e(M["pack_version"])} &middot; Credits used: about {e(re.sub(r"^\s*about\s+", "", str(M["credits_used"]), flags=re.I))}</p>
<div class="note">{e(Sx["confidence_note"])}</div>
{('<p class="meta"><b>Raw HG values behind the plain-word labels:</b> ' + e(Sx["raw_values"]) + '</p>') if Sx.get("raw_values") else ""}</section>""")

# ---------- 11 Build your own plans (optional) ----------
if show_byo:
    if workflow_zip:
        zb = open(workflow_zip, "rb").read()
        zname = os.path.basename(workflow_zip)
        zuri = "data:application/zip;base64," + base64.b64encode(zb).decode()
        dl = f'<a class="dl" href="{zuri}" download="{e(zname)}"><b>Download the workflow</b><span>{e(zname)} &middot; {round(len(zb)/1024)} KB</span></a>'
    else:
        dl = ""
    add(f"""<section id="build"><h2>&sect;{SEC["build"]} Build your own account win plan with HG data over MCP</h2>
{sample_note}
<p class="take">An LLM produced this win plan by pulling HG data through HG's MCP server. {CUST} can run the same workflow on any account.</p>
<p>The zip below holds the workflow behind this page. One skill tells the LLM how to pick an account, which data to pull and how to write the plan, and it renders the finished HTML itself, so there is nothing to run. A customer pack holds {CUST}'s product IDs, the competitor product IDs, the intent topics and the thresholds.</p>
{dl}
<h3>How {CUST} would use it</h3>
<ol class="steps">
<li><b>Connect HG's MCP server</b> to the LLM {CUST} already uses, such as ChatGPT, Microsoft Copilot, Gemini or Claude. It exposes company search, installs, intent, spend, Buying Centers, reviews, contacts and web search as tools the LLM can call. HG sets up access and credits with {CUST}. This plan used about {e(re.sub(r"^\s*about\s+", "", str(M["credits_used"]), flags=re.I))} credits. <b>Sign up:</b> register at <a href="https://phoenix.hginsights.com">phoenix.hginsights.com</a> with a work email (personal addresses are not accepted), then follow the <a href="https://phoenix.hginsights.com/docs/getting-started">Getting Started guide</a> to connect your LLM. More about the product: <a href="https://hginsights.com/product/hg-mcp-server">HG MCP Server</a>.</li>
<li><b>Install the skill.</b> Download the zip above. Example in Claude: open Customize, then Skills, then Yours, click Add, choose Upload a skill and pick the zip file. Claude installs it as <code>{e(skill_folder)}</code>, and you do not need to unzip it. For Claude Code, unzip it and copy the <code>{e(skill_folder)}</code> folder into <code>~/.claude/skills/</code>. With another LLM, unzip it and attach <code>SKILL.md</code> and the folder's files as the instructions, using an LLM that can run Python.</li>
<li><b>Ask for a plan.</b> In a new chat, say &ldquo;Build me an account win plan.&rdquo; The LLM asks one question, which {CUST} product line and optionally which account. It shortlists accounts, you confirm one, and it pulls the data, writes the plan and renders the finished HTML file for you. Every figure comes from a tool result, and gaps are stated as gaps.</li>
<li><b>Add {CUST}'s own data.</b> Connect the CRM and {CUST}'s own product data as further MCP servers and extend the research skill to read them. The plan then shows open opportunities, the {CUST} products an account already uses and recent findings next to HG's view of the market (see the note above).</li>
</ol>
<p class="src">Zip contents: SKILL.md, references/ (customer pack, schema, audit, HTML fallback), scripts/ (the renderer and the logos).</p></section>""")

add("</main>")
for _k in ("pb", "co", "cod", "tl", "nl", "fw", "mu", "bd", "bl", "gr", "pu"):
    css = css.replace("@@" + _k, B[_k])
css = css.replace("@@font", B["font"])
doc = f'<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Account Win Plan: {e(M["target_account"])} for {e(M["customer"])}</title><style>{css}</style></head><body>{"".join(parts)}</body></html>'
open(out_path, "w").write(doc)
print("wrote", out_path, len(doc))
