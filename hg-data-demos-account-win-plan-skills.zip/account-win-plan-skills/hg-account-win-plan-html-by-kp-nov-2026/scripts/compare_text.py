#!/usr/bin/env python3
"""Check that a restyled plan kept the original's content.

Usage: python compare_text.py OLD.html NEW.html [--drop-id ID ...]

--drop-id ID  removes the element with id="ID" (and every <a href="#ID"> link)
              from OLD before comparing. Use it for sections the skill is
              meant to remove, e.g. --drop-id appendix.
--drop-heading TEXT  removes, from OLD, the h2/h3/h4 whose text starts with
              TEXT and everything after it up to the next heading of the same
              or higher level (e.g. --drop-heading "Reseller landscape").
--skip-id ID  leaves the element with id="ID" out of BOTH files (use for a
              section the skill is allowed to rewrite, e.g. --skip-id why when
              Why Now was condensed; check it with check_condensed.py instead).
--replace "A=>B"        replaces every A with B in OLD's text before comparing.
--replace-first "A=>B"  replaces only the first A with B.
              B may be empty to delete text (e.g. --replace "Note: ...=>").
              Use these only for the wording changes the skill allows
              (e.g. --replace "company_fai=>Buying Centers"
                    --replace-first "TrustRadius=>TrustRadius, an HG Insights Company").

Compares the visible text (outside <style>/<script>/<head>) and the link
URLs (href) of the two files. Whitespace is normalised. Prints every
difference and exits 1 if there are any, 0 if the content matches.
Standard library only.
"""
import difflib
import re
import sys
from html.parser import HTMLParser

SKIP = {"style", "script", "head", "title"}


class Extract(HTMLParser):
    def __init__(self, drop_ids=(), drop_headings=()):
        super().__init__(convert_charrefs=True)
        self.drop_ids = set(drop_ids)
        self.drop_headings = tuple(drop_headings)
        self.hlevel = None      # level of heading being read
        self.hmark = None       # (chunk index, link index) at heading start
        self.hdrop = None       # level of heading whose block is being dropped
        self.drop_stack = []  # [tag, nesting] while inside a dropped element
        self.depth = 0
        self.chunks = []
        self.links = []

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if self.drop_stack:
            if tag == self.drop_stack[0][0]:
                self.drop_stack[0][1] += 1
            return
        if tag in ("h1", "h2", "h3", "h4"):
            lvl = int(tag[1])
            if self.hdrop is not None and lvl <= self.hdrop:
                self.hdrop = None
            if self.hdrop is None:
                self.hlevel, self.hmark = lvl, (len(self.chunks), len(self.links))
        if self.hdrop is not None:
            return
        href = a.get("href") or ""
        if a.get("id") in self.drop_ids or (tag == "a" and href[1:] in self.drop_ids and href.startswith("#")):
            self.drop_stack.append([tag, 1])
            return
        if tag in SKIP:
            self.depth += 1
        if tag == "a":
            href = dict(attrs).get("href")
            if href and not href.startswith("#"):
                self.links.append(href.strip())

    def handle_endtag(self, tag):
        if self.hdrop is not None and tag in ("section", "body"):
            self.hdrop = None  # a dropped block never runs past its section
        if self.drop_stack:
            if tag == self.drop_stack[0][0]:
                self.drop_stack[0][1] -= 1
                if self.drop_stack[0][1] == 0:
                    self.drop_stack.clear()
            return
        if tag in SKIP and self.depth:
            self.depth -= 1
        if self.hlevel is not None and tag == "h%d" % self.hlevel:
            text = " ".join(self.chunks[self.hmark[0]:]).strip()
            if self.drop_headings and text.startswith(self.drop_headings):
                del self.chunks[self.hmark[0]:]
                del self.links[self.hmark[1]:]
                self.hdrop = self.hlevel
            self.hlevel = None

    def handle_data(self, data):
        if not self.depth and not self.drop_stack and self.hdrop is None:
            text = re.sub(r"\s+", " ", data).strip()
            if text:
                self.chunks.append(text)


def load(path, drop_ids=(), replaces=(), drop_headings=()):
    p = Extract(drop_ids, drop_headings)
    with open(path, encoding="utf-8") as f:
        p.feed(f.read())
    text = " ".join(p.chunks)
    for a, b, first in replaces:
        text = text.replace(a, b, 1) if first else text.replace(a, b)
    text = re.sub(r"\s+", " ", text).strip()
    # One token per word: tolerant of markup regrouping, strict on content.
    words = text.split(" ")
    return words, p.links


def main():
    args = sys.argv[1:]
    drop, reps, skip, heads = [], [], [], []
    i = 0
    while i < len(args):
        if args[i] == "--drop-id":
            drop.append(args[i + 1]); del args[i:i + 2]
        elif args[i] == "--drop-heading":
            heads.append(args[i + 1]); del args[i:i + 2]
        elif args[i] == "--skip-id":
            skip.append(args[i + 1]); del args[i:i + 2]
        elif args[i] in ("--replace", "--replace-first"):
            a, b = args[i + 1].split("=>", 1)
            reps.append((a, b, args[i] == "--replace-first")); del args[i:i + 2]
        else:
            i += 1
    if len(args) != 2:
        print(__doc__)
        sys.exit(2)
    old_words, old_links = load(args[0], drop + skip, reps, heads)
    new_words, new_links = load(args[1], skip)
    problems = 0

    sm = difflib.SequenceMatcher(a=old_words, b=new_words, autojunk=False)
    for op, a1, a2, b1, b2 in sm.get_opcodes():
        if op == "equal":
            continue
        problems += 1
        ctx = " ".join(old_words[max(0, a1 - 6):a1])
        print(f"[text {op}] after: ...{ctx}")
        if a2 > a1:
            print("   old: " + " ".join(old_words[a1:a2]))
        if b2 > b1:
            print("   new: " + " ".join(new_words[b1:b2]))

    if sorted(old_links) != sorted(new_links):
        problems += 1
        missing = sorted(set(old_links) - set(new_links))
        added = sorted(set(new_links) - set(old_links))
        print("[links] differ")
        for u in missing:
            print("   missing: " + u)
        for u in added:
            print("   added:   " + u)
        if not missing and not added:
            print("   (same URLs, different counts)")

    if problems:
        print(f"\n{problems} difference(s) found.")
        sys.exit(1)
    print(f"MATCH: {len(old_words)} words and {len(old_links)} links identical.")


if __name__ == "__main__":
    main()
