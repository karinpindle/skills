#!/usr/bin/env python3
"""Check that a condensed section adds no facts that weren't in the original.

Usage: python check_condensed.py SOURCE NEW.html --id SECTION_ID

SOURCE is either the original plan HTML (the section with id=SECTION_ID is
read) or a win-plan-data JSON (why_now.paragraphs is read).
NEW.html is the output plan; the section with id=SECTION_ID is read.

Every number, date, money/percent figure and capitalised name in the new
section must also appear in the source text. Prints anything new and exits 1,
otherwise prints OK and exits 0. Standard library only.
"""
import json
import re
import sys
from html.parser import HTMLParser


class Section(HTMLParser):
    def __init__(self, sid):
        super().__init__(convert_charrefs=True)
        self.sid, self.stack, self.out = sid, [], []

    def handle_starttag(self, tag, attrs):
        if self.stack:
            if tag == self.stack[0][0]:
                self.stack[0][1] += 1
        elif dict(attrs).get("id") == self.sid:
            self.stack.append([tag, 1])

    def handle_endtag(self, tag):
        if self.stack and tag == self.stack[0][0]:
            self.stack[0][1] -= 1
            if self.stack[0][1] == 0:
                self.stack.clear()

    def handle_data(self, data):
        if self.stack:
            self.out.append(data)


def section_text(path, sid):
    p = Section(sid)
    with open(path, encoding="utf-8") as f:
        p.feed(f.read())
    return re.sub(r"\s+", " ", " ".join(p.out))


def source_text(path, sid):
    if path.endswith(".json"):
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        return " ".join((d.get("why_now") or {}).get("paragraphs") or [])
    return section_text(path, sid)


FACT = re.compile(
    r"[£$€]?\d[\d,.]*\s?(?:%|[KMB]n?\b|million|billion)?"  # numbers, money, %
    r"|\b(?:[A-Z][\w&'.-]*)(?:\s+(?:&\s+)?[A-Z][\w&'.-]*)*"  # capitalised names
)
STOP = {"The", "This", "That", "These", "Those", "It", "Its", "A", "An", "And", "But", "For",
        "In", "On", "At", "Of", "To", "With", "Our", "We", "They", "Their", "Start", "Under",
        "Since", "When", "While", "So", "Someone", "If", "As", "By", "From", "Then", "There"}


def facts(text):
    out = set()
    for m in FACT.findall(text):
        m = m.strip(" .,")
        words = m.split()
        while words and words[0] in STOP:
            words = words[1:]
        m = " ".join(words)
        if m and m not in STOP:
            out.add(m)
    return out


def main():
    a = sys.argv[1:]
    if len(a) != 4 or a[2] != "--id":
        print(__doc__)
        sys.exit(2)
    src = source_text(a[0], a[3])
    new = section_text(a[1], a[3])
    norm = lambda s: re.sub(r"\s+", " ", s)
    # Wording the skill itself requires (TrustRadius endorsement) isn't a new fact.
    allowed = {"HG Insights Company", "TrustRadius", "Buying Centers", "HG Insights"}
    missing = sorted(f for f in facts(new) if norm(f) not in norm(src) and f not in allowed)
    if missing:
        print("Not found in the original (check each is a fact from the source, not new):")
        for f in missing:
            print("  - " + f)
        sys.exit(1)
    print("OK: every number and name in the condensed section appears in the original.")


if __name__ == "__main__":
    main()
