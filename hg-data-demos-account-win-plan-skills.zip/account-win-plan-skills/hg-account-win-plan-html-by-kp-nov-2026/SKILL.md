---
name: "hg-account-win-plan-html-by-kp-nov-2026"
description: "Render an HG Insights Account Win Plan as a single on-brand HTML file (2026 HG brand: Prussian Blue, Vibrant Coral, new logo) from a win-plan-data JSON produced by hg-account-win-plan-research-by-kp-nov-2026, or restyle an existing account-win-plan HTML into the new brand without changing its content. Use when the user has a win-plan-data-*.json or an older account-win-plan-*.html or account-brief-*.html (the old name), or says 'build the HTML for the account win plan', 're-render the plan', 'restyle the plan', 'rebrand the plan', or 'put this plan in the new HG branding' (also 'account brief', the old name). Does NOT pull data or spend credits; if there is neither a JSON nor a plan HTML, run hg-account-win-plan-research-by-kp-nov-2026 first."
---

# Account Win Plan: HTML renderer

This is the formatting half of the Account Win Plan workflow. The research skill (`hg-account-win-plan-research-by-kp-nov-2026`) pulls and writes the data; this skill turns it into HTML. It makes no MCP data calls and spends no credits.

The look follows the **2026 HG Insights brand** (rebrand of 2026-10-06). `references/format.md` holds the full system. The short version: Prussian Blue `#071834` and warm neutrals carry the page, Vibrant Coral `#FF4A4A` is used sparingly as the signal, the new logo sits in `assets/`, and the font stack is `"Google Sans", Arial`.

## Two modes

**Render mode (default):** the input is a `win-plan-data-[company]-[YYYY-MM-DD].json` matching `references/win-plan-data-schema.md`.

**Restyle mode:** the input is an existing account-win-plan `.html`, usually one built in the old navy/royal-blue brand, and the user wants it in the new brand. The content is already final and only the look changes.

If the user hasn't given a file, look in the outputs folder or any connected folder. If you find neither kind of file, ask, or offer to run the research skill.

## Render mode steps
1. Read the JSON and check it against `references/win-plan-data-schema.md`. List any missing required keys to the user instead of inventing values.
2. Read `references/format.md` (brand system, layout, section order, components).
3. **Run the renderer.** `python scripts/render_win_plan.py <win-plan-data.json> assets/hg-logo-white.png <out.html> [<workflow.zip>] [--brand <brand.json>]` produces the finished file in the 2026 HG brand, or in a customer's brand with `--brand` (see `assets/brand-securin.json`). Do this yourself; never ask the user to run it. If scripts cannot run, build the HTML by hand to match `format.md`: one self-contained file, inline CSS, no JS, logo embedded as base64.
4. The renderer stops with a message if Why Now does not hold exactly 3 strings (takeaway + 2 paragraphs) or if there are not 1 to 3 opportunities. Send those back to the research skill, or condense Why Now yourself using only facts already in it, then run `python scripts/check_condensed.py <win-plan-data.json> <new.html> --id why` and fix anything it lists.
5. The page, in order: hero (eyebrow "Account Win Plan · Prepared for [customer] on [date]", Motion / Industry (HG) / HQ tags, stat tiles with no Total IT or Total AI spend), **Quick Start**, then §1 Why Now, §2 Opps to Win, §3 Tech Spend, §4 Tech Signals, §5 Intent Signals, §6 News Signals, §7 Peers Comparison (if `peers`), §8 Competitive Battle Card, §9 Contacts & Outreach Drafts (Buying Centers panel, contacts, talk track, emails), §10 Sources, §11 Build Your Own Account Win Plan (always: pass the workflow zip; if none was given, ask the research skill to package one rather than leaving the section out). Numbers follow the sections present. There is no appendix and no separate Outreach section.
6. Check the output with a screenshot (Playwright, element screenshots per section) before presenting: nav fits, two-column grids render, no section is empty, no raw HG scores show outside Sources.
7. Save as `account-win-plan-[company]-[YYYY-MM-DD].html` in the outputs folder and present it.

## Restyle mode steps
Every word, number, name, quote, date and link in the old plan was checked when it was made. The job is to change the clothes, not the body.
1. Read the old HTML in full. Note its sections, their order, and every component (tables, chips, matrices, SVG charts, quotes, email blocks).
2. Read `references/format.md`.
3. Write a new file: replace the `<style>` block with one built from `format.md`, swap the old logo for `assets/hg-logo-white.png` (base64), remove any external font `@import` or `<link>`, and adjust class names and markup only as far as the new components need. Recolor inline SVG chart lines so each takes its opportunity's color (see Install trend chart in `format.md`; the mapping comes from the Aligned play chips in the plan's Tech Signals table), without touching data points, labels or periods.
4. Keep content verbatim: same sections in the same order, same text, figures, names, quotes, dates and URLs. Don't add, drop, reword, round or reorder anything. If the old plan is missing a section, don't create it. Restyle does not reorder an old plan into the new section order or add Quick Start, Peers or the AI blocks; if the user wants the new layout, offer to rerun the research skill for that account.
   These are the only content changes allowed, and you make them without asking:
   - **Remove any Appendix section** (e.g. "§11 Appendix: all product installs") together with its nav link. The plan has no appendix; Sources & Methodology is always the last section. Note its `id` (usually `appendix`) for step 5.
   - **Remove any Reseller section** (e.g. a "Reseller landscape" block listing the seller's channel rivals): delete its heading and everything under it up to the next heading. The plan never has a reseller section. Note its heading text for step 5.
   - **Buying Centers wording:** replace every visible `company_fai` with "Buying Centers" (so "HG Insights company_fai" becomes "HG Insights Buying Centers"), and any standalone "FAI" label with "Buying Centers". Where the old text already explains the tool, as in "company_fai (Buying Centers)", drop the parenthetical so it doesn't read "Buying Centers (Buying Centers)".
   - **TrustRadius naming:** make the first visible mention of "TrustRadius" read "TrustRadius, an HG Insights Company" (unless it already does). It's an aside, so when the sentence carries on after it, close it with a comma ("read the reviews on TrustRadius, an HG Insights Company, on 27 September"). Don't add the comma before a period or other punctuation. Leave later mentions as "TrustRadius"; change "HG TrustRadius" or "TrustRadius by HG Insights" to "TrustRadius".
   - **Why Now length:** if Why Now has more than 2 paragraphs after the bold takeaway, condense them into 2 (see "Why Now (exactly 2 paragraphs, to the point)" in `format.md`): why this account, why now, then what the seller can do to earn the business. Keep the takeaway word for word. Use only facts already in that section, and tell the user what detail was dropped.
   - **Contacts note:** delete the line "Note: The contacts in this brief may not match the leads delivered." (and its wrapper element) if the old plan has it. The plan no longer carries this note.
   List each of these changes for the user when you present the file.
5. Verify with `python scripts/compare_text.py <old.html> <new.html> --drop-id <appendix-id> --replace "company_fai (Buying Centers)=>Buying Centers" --replace "company_fai=>Buying Centers" --replace-first "TrustRadius=>TrustRadius, an HG Insights Company,"`. Replacements run in the order given, so keep the parenthetical one first. Use `"TrustRadius=>TrustRadius, an HG Insights Company"` (no trailing comma) if the first mention is followed by punctuation. Add `--replace "Note: The contacts in this brief may not match the leads delivered.=>"` if you deleted the contacts note. If you removed a reseller block, add `--drop-heading "<its heading text>"`. If the first TrustRadius mention sits inside a section you skip, leave `--replace-first` out (otherwise it would rename the wrong mention). If you condensed Why Now, add `--skip-id why` (use the section's actual id) and also run `python scripts/check_condensed.py <old.html> <new.html> --id why`; for each item it lists, confirm it's a fact from the original section or remove it. Include only the options for changes you actually made (add `--replace "FAI=>Buying Centers"` if you replaced a standalone FAI label). It compares the visible text and the link URLs of both files and lists every difference. Fix every difference until it reports a match.
6. If the old plan breaks a rule below in any way not covered by the allowed changes in step 4 (for example, TrustRadius intent called "first-party", or a third-party provider named), don't silently fix it. Keep it, then list each instance for the user and ask whether to change it.
7. Save beside the original as `account-win-plan-[company]-[YYYY-MM-DD]-restyled.html` so the original stays untouched, and present it.

## Rules
- Render content verbatim. Don't add, round, reword or "improve" figures, quotes, names or claims. Fix layout, not content.
- If a value is `null`, show "No HG data available for X".
- Labelling: "Buying Centers" (never "FAI" or the tool name `company_fai`; write "HG Insights Buying Centers" in sources). The §9 "how HG picks the contacts" note may spell out "HG's Functional Area Intelligence" once. TrustRadius intent is buyer intent, never "first-party". Bidstream is labelled "Contextual Intent (bidstream)".
- TrustRadius naming: first visible mention "TrustRadius, an HG Insights Company", later mentions "TrustRadius". Never "HG TrustRadius" or "TrustRadius by HG Insights".
- Plain words: the body shows Use level (Heavy / Moderate / Light), intent strength words, AI maturity and cloud levels, never the raw HG numbers. Raw values appear only in Sources.
- Tie HG data to opportunities: every block that supports an opportunity carries its Opp chip. Whenever an opportunity is named, its number comes first: "Opp 1: [name]".
- Opportunities: keep "Opps" (never rename them "plays"); 1 to 3, never padded.
- The customer has no CRM link in the plan: relationship history is a prompt box for the seller ("add from your CRM"), never stated as fact.
- Contacts show tenure at the account; email and mobile appear only as blurred placeholders with the DPA note (the note is hidden when `audience` is internal; Build Your Own is not). Never name the contact-data provider.
- Competitors at the account may be named. Never name the seller's other customers to the account (peer names stay in the internal plan and are not for outreach copy).
- Watch cells in the battle card use the bright yellow highlight from `format.md`.
- No reseller section, no Opportunity Matrix or Wedge Strategy sections, no appendix, and no Install trend block without real data.
- Content changes go back to the research skill, then re-render.
