# Pre-ship audit

Run before handing over the plan. Fix or disclose every "no".

- [ ] Step 0 done: skill library loaded, or the gap was stated.
- [ ] Customer and product line both confirmed by the user.
- [ ] Customer pack frozen and reviewed; intent queried only with its IDs.
- [ ] Account status shown as a Motion tag and in plain words in Quick Start (HG-detected, rep to confirm); the framing matches it. No relationship history stated as fact; `relationship_prompts` cover it.
- [ ] Account placed in one installs x intent quadrant, with HIGH-only intent (85+, 90 days). MEDIUM is labelled context only.
- [ ] TrustRadius signals show page type and products compared.
- [ ] Every figure, contact, install and quote traces to a tool call.
- [ ] Domain consistency: alternate domains checked before any "no data" claim.
- [ ] Completeness: no call returned exactly its limit without a re-pull or a stated truncation.
- [ ] Review quotes match the target's industry or size, are under 24 months old, and incentivized ones are flagged or dropped.
- [ ] `humanizer` run on prose and emails.
- [ ] win-plan-data JSON matches `win-plan-data-schema.md` and was handed to the HTML skill.
- [ ] No "FAI" label and no `company_fai` anywhere (source lines and Data Sources say "HG Insights Buying Centers"); no "first-party" for TrustRadius; no names of HG's own data providers (competitors at the account may be named); none of the seller's other customers named in outreach.
- [ ] Why Now is a one-line takeaway plus exactly 2 short paragraphs: (1) why this account, why now; (2) what the seller can do to earn the business. No tool names, scores, intensity numbers, dates of verification or methodology in it.
- [ ] First TrustRadius mention reads "TrustRadius, an HG Insights Company".
- [ ] No reseller or channel-rival section, and no appendix.
- [ ] Opps to win is one combined block with no more than 3 opportunities, and each one is backed by real signals (none added just to reach 2 or 3) (no separate Opportunity Matrix or Wedge Strategy sections).
- [ ] `trend_story` is included only when it shows a real change; every marker has a one-line event; no invented periods or values.
- [ ] Build Your Own (§11) is present in every plan, customer or internal: sample note at the top of §11, section after Sources, zip embedded, no dashes, and no claims beyond what the workflow does.
- [ ] Credits used reported in Data Sources; Known pitfalls updated.
- [ ] No install intensity numbers in Why Now; the installs matrix graphic is off unless asked for.
- [ ] Opp 1/2/3 numbers appear in every section that refers to an opportunity (Why Now text, Buying Centers, Intent, Competitive headers, Contacts, Outreach), not just the names, and every named opportunity reads "Opp N: [name]" with the number first.
- [ ] Tech Signals shows "Installed (first to last verified)" from the technographic record and Use level (not raw intensity), with the definition under the table.
- [ ] Intent opens with a seller summary ("What this means for you") right under the section title.
- [ ] Customer partnerships and OEM relationships with vendors in the stack were checked and reflected in the status note, opportunities and competitive matrix; unverified claims are labelled.
- [ ] Build Your Own: "LLM" wording, sign-up links, install steps with the Claude path, no "review the zip" instruction, no render step, and the zip uploads as a skill.

- [ ] Section order: Quick Start, Why Now, Opps to Win, Tech Spend, Tech Signals, Intent Signals, News Signals, Peers Comparison, Competitive Battle Card, Contacts & Outreach Drafts, Sources, Build Your Own.
- [ ] Quick Start: one Why-now signal and one focus contact per opportunity, plain-word status and competition, sample angles, and a `call` plan; the emails live only in §9.
- [ ] Plain words in the body (Use level, Strong/Moderate signal, Early/Developing/Advanced, High/Medium/Low); raw values only in `sources.raw_values`. Interpretations marked "our read".
- [ ] Each story told once; no section repeats another's evidence.
- [ ] AI maturity, AI spend (inside Projected IT Spend) and top AI products pulled, or their absence stated.
- [ ] Peers (if included): up to 3, same metrics as the target, each row tied to an opportunity.
- [ ] Intent: Contextual Intent (bidstream) cards use strength words; TrustRadius patterns present, or "No relevant TrustRadius intent."
- [ ] Battle card: one column per opportunity, Watch highlighted, head-to-heads sourced from the win pages; no repeated findings.
- [ ] Contacts: picked to match Buying Centers teams, tenure from employment history (reveals off), executive sponsors cite a public source; email and mobile never revealed.
- [ ] Hero tiles: no Total IT spend and no Total AI spend; only revenue, employees, rank and the spend categories relevant to the opportunities.
