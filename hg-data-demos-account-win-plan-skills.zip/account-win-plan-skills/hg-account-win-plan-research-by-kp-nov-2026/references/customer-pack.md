# Customer pack (frozen lists)

Freeze these once per customer and product line, have a human check them for relevance and accuracy, then query intent and installs only with these IDs. Save the filled copy next to the plan.

Customer: `[customer]`   Product line / play: `[line]`   Version/date: `[YYYY-MM-DD]`   Reviewed by: `[name]`

## 1. Customer's own install IDs
| Product | Vendor | Product ID | Notes |
|---|---|---|---|

## 2. Competitor product IDs (grouped by product line)
| Line | Competitor | Vendor | Product ID |
|---|---|---|---|

## 3. HG intent topic IDs (bidstream)
Find with `hg-intent-topic-explorer` (semantic search), not substring matching.
| Group (own / competitor) | Topic | Topic ID | Why relevant |
|---|---|---|---|

## 4. TrustRadius filters
No topics exist for TrustRadius; use IDs from the product catalog.
| Vendor | Vendor ID | Product ID(s) | Product category ID(s) |
|---|---|---|---|

## 5. AI and peers
- AI product attribute IDs for the AI-tagged technographic pull: 532 (AI), 931 (GenAI), 545 (ML/DL), 567 (ML framework)
- Peers (up to 3) and why each was chosen:
| Peer | Domain | Why a peer |
|---|---|---|

## 6. Thresholds
- Installed = verified within 12 months, intensity >= `[floor]`
- Intent = HIGH (score >= 85), last 90 days; MEDIUM only as labelled context
- Plain-word bands: Use level Heavy >=50% / Moderate >=15% of the top install; intent Strong 85+ / Moderate 65-84; AI maturity Early <=33 / Developing / Advanced >=67
- Credit budget per account: `[n]` credits; stop-and-ask above `[n]`

## Notes
Anything that needed a judgment call (excluded topics, ambiguous products).
