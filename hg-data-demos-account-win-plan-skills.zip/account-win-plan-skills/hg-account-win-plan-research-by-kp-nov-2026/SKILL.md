---
name: "hg-account-win-plan-research-by-kp-nov-2026"
description: "Research and write an Account Win Plan (data + narrative, saved as JSON; HTML is rendered by hg-account-win-plan-html-by-kp-nov-2026) that HG Insights sellers use to win a prospect. The core motion: HG is trying to win a CUSTOMER, and this skill proves HG's value by identifying one of THAT customer's own best-fit target accounts and building the plan their reps would use to go win it. Use this whenever a seller says they're trying to win/land/close a customer, wants to show a prospect what HG data can do, asks for an account win plan (or the older names 'account plan', 'account brief'), account intelligence, a deep dive, pre-call prep, or 'help me prep for [prospect]'. The skill FIRST asks which customer HG is trying to win and which product line or play to feature, then helps identify the best-fit target account, then builds the plan. Do NOT use for building slide decks (use deck-creation/sales-deck-builder) or for scoring/list-building across many accounts (use scoring-with-dc-methodology)."
---

# Account Win Plan

This skill does the **research and writing** for an Account Win Plan for one sales motion at HG Insights: **HG is trying to win a customer, and the most persuasive proof of HG's value is the exact deliverable that customer's own sales team would want** — a sharp, data-rich plan on one of *their* best-fit target accounts.

Two companies are in play; keep them straight:

- **The customer** — the company HG is trying to win (e.g. Cisco). The plan is *for* them.
- **The target account** — one of the customer's best-fit prospects (e.g. Kraft Heinz). The plan is *about* them.

Write the plan as if the customer's own sales team produced it to win the target account. Fuse HG data (firmographics, installs, Buying Centers, IT/cloud spend, intent, reviews, contacts) with HG GTM research, so the reader gets a point of view, not a data dump.

**This skill covers data and content only and ends by writing a `win-plan-data` JSON.** The HTML is built by the companion skill `hg-account-win-plan-html-by-kp-nov-2026`, which needs no data calls. The JSON contract is `references/win-plan-data-schema.md`; the frozen-ID template is `references/customer-pack.md`; the pre-ship checklist is `references/audit.md`.

## Core operating principles

- **Ask the user questions.** Begin by asking which HG customer the plan is for and which product line or play to feature. Check in before locking a target account.
- **Never fabricate anything.** Every number, company, contact, install, department share, spend figure, intent signal, headline and quote must trace to a real tool result. If data isn't there, say so.
- **Do not make assumptions.** Don't infer the customer, target account, product line, account status or any figure from context or prior knowledge.
- **Stay within the credit budget.** Estimate credits before pulling (see Step 1) and stop and ask above the threshold.

## Step 0 — Load the GTM skill library (mandatory, before anything else)

1. If the `gtm-hg-mcp` skill bundle is installed, load it.
2. Otherwise fetch the library from `https://phoenix.hginsights.com/gtm/skills`.
3. If neither works, tell the user which skills could not be loaded and continue, reading the notes in this file instead. Do not silently skip.

Read the matching skill *before* each step:

| Before | Read |
|---|---|
| Step 1 (customer research, customer pack) | `research-hg`, HG MCP tool-calling skill |
| Step 2 (target search, intent) | HG intent skill, `hg-intent-topic-explorer` |
| Step 3 (prose) | `humanizer` |

## Tool names (HG MCP v2)

The tool server prefix varies by session; match on base name. v1 names no longer exist:

| Old (v1) | Use (v2) |
|---|---|
| `company_research` | `company_firmographic`, `company_enrich`, plus targeted calls below |
| `get_company_hierarchy` | `company_hierarchy` |
| `list_product_categories` | `get_product_category` |
| `intent_category`, `vendor_name` | `company_intent`, with `list_intent_topics` to resolve topics |

Other tools used: `search_companies`, `company_technographic`, `company_install_time_series`, `company_fai`, `company_spend`, `company_ai_spend`, `company_ai_maturity`, `company_contracts`, `get_product_information`, `get_product_attribute`, `get_vendor_information`, `get_product_reviews`, `contact_search`, `contact_enrich`, `web_search`.

If a call fails because a tool name differs, check the current tool list and map it; record the mapping under Known pitfalls.

## Step 1 — Establish the customer and the play

Open with one AskUserQuestion containing both, because the answer changes everything downstream:

> **Which HG customer are you preparing this for, and which of their product lines or plays should the plan feature?**

Both are required. A customer such as Cisco has several unrelated plays; do not guess.

Then:

- Resolve the customer to a domain; run `company_firmographic`.
- Work out what they sell, who buys it, and their ICP. Use their site/positioning, `research-hg`, and web search.
- **Build or load the customer pack** for that customer and product line (`references/customer-pack.md`). Freeze it before pulling account data:
  - customer's own install IDs
  - competitor product IDs, grouped by product line
  - HG intent topic IDs for own products and for competitors (find topics with `hg-intent-topic-explorer`, which is semantic search over ~21,000 topics; `list_intent_topics` only matches substrings)
  - TrustRadius filters (vendor IDs, product IDs, product category IDs; from the product catalog, there are no TrustRadius topics)
  - Show the lists to the user for a relevance check before using them.
- **Ask who the plan is for**: a sample for a customer HG is trying to win (`meta.audience: "customer"`) or the seller's own team (`"internal"`, which hides only the DPA note). Build Your Own is included either way.
- **Estimate the credit budget** for one account and state it. Typical full plan: firmographic 0.1, technographic 2 (plus 2 for the AI-tagged pull), install time series 3 per product, Buying Centers 2, intent 0.1 per call, spend 3, AI spend 2, AI maturity 2, contracts 1, contact search 2, contact enrich 0 with reveals off, plus about 6 per peer for 3 peers (firmographic, technographic, AI maturity, AI spend). That is roughly 50 to 70 credits. Stop and ask if it exceeds the threshold the user sets, or 50 credits if none is set.

## Step 2 — Recommend the best-fit target account

Do the hunt yourself, but let the user override.

- Use `search_companies` on the ICP firmographics.
- Use `company_intent` restricted to the frozen pack IDs to find accounts with HIGH intent (see Intent rules).
- Use `company_technographic` for stack fit.
- Classify each candidate into one quadrant for the chosen product line (see Installs x intent matrix). Rank the shortlist by quadrant, then score: displacement first for net-new plays; expansion and churn risk first for existing customers. Whitespace is a fifth group.
- Build a 3-5 account shortlist with a one-line, signal-grounded "why this fits", naming the quadrant.
- Recommend one account and proceed by default. Offer alternatives via AskUserQuestion (recommended account first, others, "Other"). Skip the question if the user already named an account; sanity-check the ICP framing only.

## Step 3 — Build the plan

1. Pull deep data on the target account (Data gathering).
2. **Classify account status** and the matrix quadrant (below).
3. Write the plan (Plan structure).
4. Run `humanizer` on all prose.
5. Write `win-plan-data-[company]-[YYYY-MM-DD].json` per `references/win-plan-data-schema.md`.
6. Run `references/audit.md`, then hand the JSON to `hg-account-win-plan-html-by-kp-nov-2026`, which renders the HTML itself (its `scripts/render_win_plan.py`). The user never has to run a script.

## Account status (branch on this)

Using the frozen own-install IDs against `company_technographic`:

| Status | Test | Framing |
|---|---|---|
| **CURRENT** | a customer product verified in the last 12 months | expansion and cross-sell |
| **LAPSED** | customer product detected, latest verification older than 12 months | win-back |
| **NET-NEW** | no customer product detected | displacement or whitespace |

State the status as a **Motion** tag in the hero (e.g. "Win-back of a former HG customer"; this replaces the old status chip) and in plain words in Quick Start (`quick_start.status`, no "LAPSED"-style labels), noting it is HG-detected and the rep should confirm. Add `meta.status_short`. The status changes the plays, the opportunity names and the email angles. Do not write a net-new plan for an account that is CURRENT.

**When HG itself is the customer** (the plan is for an HG seller, e.g. winning back a former HG customer): HG's own products are not in the catalog under "HG Insights", so use HG's legacy product installs (for example Intricately, product 19606, vendor 7624) as the own-install IDs for this test. When the plan is for an HG prospect or customer (e.g. Appfire), use that customer's own product IDs only; never apply the HG-product test.

**Relationship history is the seller's to add.** The plan is a template the customer's sellers use, and HG has no access to their CRM or other first-party systems. Never state why a former customer left, what they paid or who championed the product. Instead write `why_now.relationship_prompts` (what they bought and when it ended, why they left, who championed it, open opportunities) for the "add from your CRM" box.

## Data gathering

"Relevant" means relevant to the customer's product line: installs it complements or displaces, intent its buyers show, departments that own the decision. Pull real data before writing.

- **Firmographics / hierarchy** — `company_firmographic` (size, revenue, industry, HQ, rank); `company_enrich` for gaps; `company_hierarchy` when parent/subsidiary structure matters. HG resolves a domain to its corporate parent; if the buyer is a subsidiary, say so.
- **Tech landscape** — `company_technographic` sorted by intensity, filtered to the pack's own and competitor product IDs plus the play-relevant categories (`get_product_category`). Fields: `intensity`, `firstVerifiedDate`, `lastVerifiedDate`. `company_install_time_series` only for the main products behind each opportunity (3 credits per product, 24 to 36 months). Sum detection days per opportunity into `trend_story.series`, mark the months where the stack changed (first or last detection of a product) as numbered markers, and explain each in one line in `events`. Include the trend only when it shows a real change; otherwise omit `trend_story`. For the installs table, take the installed dates from the `company_technographic` record (first and last verified month), not from Buying Centers dates, which can differ. Do not pull the full unfiltered footprint.
- **Buying Centers** — `company_fai` maps which departments, roles and locations use each product. It goes in `tech_signals.teams` and renders inside §9 Contacts, because it is how contacts are picked: match contact titles and locations to the teams that use the product most. Call it **Buying Centers**; the one "how HG picks contacts" note may spell out "HG's Functional Area Intelligence". Never write "FAI" or `company_fai` anywhere in the plan (sources say "HG Insights Buying Centers").
- **AI** — `company_ai_maturity` (maturity score, rank, data maturity, cloud mix) and `company_ai_spend` (total AI spend and sub-categories). Pull AI-tagged installs with `company_technographic` filtered to product attributes 532 (AI), 931 (GenAI), 545 (ML/DL) and 567 (ML framework) and list the top AI products in use. Render in `tech_signals.ai_maturity` (four tiles: AI maturity, AI products in use, Data maturity, Cloud mix) and `tech_spend.ai_rows`.
- **Peers** — up to 3 direct competitors of the target (from its own filings or positioning, confirmed with `search_companies`/firmographic). For each: firmographic, technographic on the pack IDs, AI maturity, AI spend. Feeds `peers`. Peers are context for the seller; never name them as the seller's customers in outreach.
- **Contracts and proof points** — `company_contracts` for announced renewals or deals on the competing products (state "none announced" when empty). For proof-point counts ("X US companies with 1,000+ employees use Y"), use `search_companies` with `limit: 1` and read `total_count`.
- **Intent** — `company_intent`, source chosen by the field group (there is no `source` parameter). See Intent rules.
- **Spend** — `company_spend` for IT/cloud spend by category. Label as HG directional estimates.
- **Competitive** — `get_product_reviews` for competitors found in the stack. Quote selection rules:
  - same industry or similar size as the target account; otherwise omit the quote
  - published within the last 24 months
  - skip or flag incentivized reviews
  - attribute to reviewer name or handle/role plus a direct trustradius.com link; if not returned, find it via `web_search`; confirm before attaching; otherwise attribute generically ("TrustRadius review")
- **Contacts** — `contact_search` with `personTitles`/`personSeniorities` for the titles the Buying Centers point to, all variants in ONE call. `contact_enrich` the chosen contacts with `revealEmail: false` and `revealPhone: false` (0 credits) to read `employmentHistory` for tenure ("since Mon YYYY") and to check who held a role at the time of a past decision. Executive sponsors may come from public sources (press releases, earnings calls); cite them in `public_source`.
- **Competitive head-to-heads** — read the seller's win/battle-card pages (for HG: the GTM Knowledge Base in Confluence, "How does HG Insights win against …" pages) for each competitor at the account: their angle, our counter, a trap question. Only use claims those pages support.
- **Customer partnerships.** Check with `web_search` (the customer's press releases and partner pages) whether the customer partners with, embeds or OEMs any vendor in the account's stack, or the reverse. A partner is not a rival: say so in the status note, show it in the Competitive matrix, and rework any opportunity that would cut across the partner's channel (add a "brief the partner team first" step and never position against the partner). Also say that the account may already receive the customer's technology indirectly through the partner and that HG may not see it. State what you verified and what you did not (for example which products are embedded).
- **Narrative** — customer positioning, Step 1 ICP research, `web_search`, `research-hg`. If nothing to draw on, tie Why Now, Opportunities and the email angle to the account's own signals.

If a tool returns empty or `found: false`, that is a finding. Note the gap; never guess.

### Intent rules

`company_intent` has no `source` parameter; the field group sets the source.

- `fields: ["topics"]` returns HG topics (bidstream). Filters: `topic_ids`, `signal_level`, `buyers_journey_names`, `context_type_names`. These apply to HG topics only.
- `fields: ["activities"]` returns TrustRadius activities. Filters: `vendor_ids`, `product_ids`, `product_category_ids`, `signal_date`.

Always query with the frozen pack IDs, never the account's whole topic list (a large enterprise can have 12,000+ active topics).

- **Keep HIGH only** (score 85 or above; shown to sellers as "Strong signal" with its trend, never the number), seen in the last 90 days, for selecting, placing and ranking the account. MEDIUM may appear as labelled supporting context, never to place or rank.
- **Name bidstream "Contextual Intent"** in the plan ("Contextual Intent activity patterns (bidstream)").
- **TrustRadius patterns are always shown.** Group the account's TrustRadius activities into patterns relevant to the play (e.g. CRM and marketing-tool comparisons that the seller's data feeds) in `intent.tr_patterns`. If none are relevant, leave `patterns` empty; the plan says "No relevant TrustRadius intent."
- **Label confidence.** TrustRadius buyer intent = product research activity on TrustRadius; never call it "first-party". Bidstream = directional, corroborating only. TrustRadius activity counts above bidstream.
- **Read TrustRadius by activity type.** Each activity carries `activity_label` (Comparison, Reviews and Ratings, Pricing, Product Listing) and `intent_signal_url`. Parse the URL to recover the page type and, for comparisons, the products compared.
  - Listing = early awareness; Reviews = checking credibility; Pricing = building a budget case; Comparison = names the shortlist.
  - Weight Pricing and Comparison above Reviews, and Reviews above Listing. Report the page type and products compared, not just "TrustRadius activity".

### Installs x intent matrix

Score installs and intent separately, then combine. "Installed" = verified in the last 12 months at or above an intensity floor you state. "Intent" = HIGH, last 90 days.

| | Intent on customer's own products | Intent on competitor products |
|---|---|---|
| **Customer's product installed** | **Expansion**: upsell and cross-sell | **Churn risk**: defend and retain first; do not cross-sell |
| **Competitor installed** | **Displacement**: takeout; best net-new target | **Competitor entrenched or re-evaluating**: intercept only if intent is on a *different* competitor than the one installed; otherwise deprioritize |

Accounts with no install on the line and intent in the category are **Whitespace**. Say the target account's quadrant in Why Now in words and reflect it in the Motion tag; the matrix graphic is optional and off by default. The same matrix run across the customer's existing accounts gives a churn-risk list; offer it as an adjacent next step.

### Data-reading rules

- **Domain consistency.** The same company can have different domains in different sources (for example HG `kraftheinzcompany.com` vs the contact provider's `kraftheinz.com`). Check both before concluding "no data" or "no contacts", and use one canonical domain per call in the source lines.
- **Completeness.** A call that returns exactly its limit has been cut off. After every call, compare the count to the limit; re-pull with a higher limit or pagination, or state the truncation in the plan.
- **Empty is a finding**, not a retry prompt.

### Known pitfalls (append after every run)

- v1 tool names were renamed in v2 (see Tool names).
- Subsidiary vs parent domains return different contact sets (Kraft Heinz, 2026-09-29).
- Review quotes pulled for the wrong industry or size read as off-topic (Banco do Brasil and Paraná Banco quotes in a food-manufacturer plan).
- Add new entries here with the date and account.

## Plain words and raw values

Sellers read plain words; the raw HG values go only in `sources.raw_values`.

| Signal | Plain word |
|---|---|
| Install intensity | Use level: Heavy (≥50% of the highest in the installs table), Moderate (≥15%), Light (the renderer computes this from `intensity`) |
| Intent score | Strong signal (85+), Moderate (65 to 84), Weak (below 65), plus trend (rising / steady / falling) |
| AI maturity score | Early (≤33), Developing (34 to 66), Advanced (≥67) |
| Cloud share | High (the main provider), Medium (≥50% of the main one), Low |

Mark your own interpretations as "our read". Tell each story once, in the section that owns it, and point to it elsewhere ("see Why Now").

## Plan structure (section order is fixed)

Drop a section only when the data can't support it. Lead each section with the takeaway, then data, then a one-line source. Tie every data block to the opportunity it supports with `opp_id` / `opp_ids`.

- **Header** — `header.one_liner`, tags as `{label, value}`: Motion, Industry (HG), HQ (city and country), and 4 to 6 stat tiles: revenue, employees, rank and only the spend categories relevant to the opportunities. Never Total IT spend or Total AI spend in the header; those stay in §3. The renderer writes "Account Win Plan · Prepared for [customer] on [date]" from `meta`.
- **Quick Start** (`quick_start`) — the 60-second read: summary; one Why-now signal per opportunity (headline, detail, "So what", source); plain-word customer status and competition; Where to focus (one contact per opportunity, contact first); suggested messaging angles as sample discovery questions; the call plan (`call`: opener, questions, ask, what to avoid), which renders as the talk track in §9 and is linked from Quick Start's "Call or send first" box along with the emails.
- **§1 Why now** — a takeaway plus **exactly 2 paragraphs** (~80 to 100 words each): why this account, why now; then what the seller can do to earn the business. No tool names, scores, intensity, verification dates, page types or methodology. Plus `relationship_prompts`.
- **§2 Opps to win** — 1 to 3 opportunities, only those the signals support; never pad. Call them "Opps", never "plays". `items` (bare names), `matrix` (tier, rationale, timeline), optional `wedge`. Number first everywhere: "Opp 1: [name]".
- **§3 Tech spend** — `takeaways.spend`, one pool per opportunity (`pools`), overlap and not-addressable notes, IT rows plus AI rows (one "Projected IT Spend" table; AI rows are part of Total IT, never added). HG modelled estimates.
- **§4 Tech signals** — installs (raw `intensity`, rendered as Use level), `intensity_definition`, `trend_story` (summed detection days per opportunity over 12 to 36 months, numbered markers with one-line events; only with a real trajectory, never invented), then `ai_maturity`.
- **§5 Intent signals** — `takeaways.intent` ("What this means for you: …"), `so_what`, Contextual Intent cards (HIGH only), TrustRadius patterns (always), moderate topics as supporting context.
- **§6 News signals** — real items per opportunity via `web_search`, last 6 to 12 months, with link. Takeaway may be left to the default.
- **§7 Peers comparison** — `peers` (optional).
- **§8 Competitive battle card** — heat matrix (`landscape.opp_ids`, `threat_by_opp`), then `head_to_head` cards; quotes only when they meet the selection rules. No `findings` prose that repeats the matrix.
- **§9 Contacts and outreach drafts** — `contacts.lead_with`; Buying Centers (`tech_signals.teams`, with the contacts matched to each team); 4 to 8 contacts grouped by role in the deal with tenure, angle and optional opening line; then one email per opportunity (`outreach`) to the person who owns it. The talk track comes from `quick_start.call`.
- **§10 Sources** — data set per section with Opp chips, pull date, frozen-list version, credits used, confidence note, `raw_values`.
- **§11 Build your own account win plan** — always included, for every audience. Package the installable skill zip (see Deliverables) every run and pass it to the HTML skill. The "sample uses HG data only" note sits at the top of this section. Wording in the HTML skill's `references/build-your-own.md`.

## Always humanize the writing

Run the `humanizer` skill on Quick Start, Why Now, Opps to win, takeaways, News blurbs, head-to-heads, contact angles, the talk track and the emails before finalizing, and again on any section you rewrite. Data, figures and citations stay exactly as pulled. If `humanizer` is unavailable, edit the prose by hand to remove filler and say so in your reply.

## Deliverables

Save `win-plan-data-[company]-[YYYY-MM-DD].json` (schema in `references/win-plan-data-schema.md`), then invoke `hg-account-win-plan-html-by-kp-nov-2026` to render `account-win-plan-[company]-[YYYY-MM-DD].html`. To restyle or re-render later, use the HTML skill on the saved JSON; no new pulls or credits.

Also save the workflow files used for this run (copies of both skills' `SKILL.md`, `references/customer-pack.md` filled in for this customer and line) next to the plan. The workflow is the reusable asset; the plan is one run of it.

Every run, package an **installable skill** for the customer: one folder named `<customer>-account-win-plan/` containing `SKILL.md` (this research skill adapted to the customer: customer fixed, only ask which play and optionally which account, and a final step that renders the HTML itself by running `scripts/render_win_plan.py` so the user runs nothing), `references/` (customer pack, schema, audit, HTML fallback), and `scripts/` (the renderer, the HG logo, the customer logo and a `brand.json`). Zip it as `HG Insights - Account Win Plan Skill - <Customer> - <Mon D YYYY>.zip` and pass that zip to the HTML skill to embed. The zip must upload cleanly as a skill in Claude (SKILL.md with name and description frontmatter at the folder root). Renderers must read the account name, short name, domain and customer from the JSON `meta` block, never hard-code an account.

**HG internal vs client handoff.** This skill is built for HG internal use: it asks which HG customer the plan is for and frames the output as HG's proof of value. Before giving the workflow to a client, adapt it: fix the customer to the client itself, remove the "which HG customer" question and the HG-selling framing, and keep the frozen pack for the client's own lines.

## Guardrails

- Run `humanizer` on prose and emails before finalizing; never ship un-humanized copy.
- Every figure, contact, install, department share and intent signal comes from an actual tool result. No filler estimates dressed as data.
- Separate HG proprietary data (cite the tool), HG GTM research, and your own synthesis (marked as a read, e.g. "this suggests...").
- Label intent confidence; never call TrustRadius intent "first-party".
- The first mention of TrustRadius in the plan reads "TrustRadius, an HG Insights Company" (with a closing comma if the sentence continues); later mentions read "TrustRadius". Never write "HG TrustRadius" or "TrustRadius by HG Insights".
- Never include a reseller or channel-rival section (who sells or manages the account's technology, or the customer's channel competitors), even if research turns it up.
- No appendix: Sources is always the last data section. The optional Build Your Own section may follow it; nothing else may.
- Never state relationship history (why a customer left, what they paid, who championed it); that comes from the seller's CRM via the prompt box.
- Never name the seller's other customers (for example the target's competitors who use the seller's product) in outreach to the target.
- Attribute all data to HG Insights. Never name the underlying provider of HG's own data (for example the contact-data source). Competitors installed at the account are named, even when they are also data vendors (in an HG plan, ZoomInfo and 6sense at the account are named as competitors). TrustRadius is HG-owned and may be named; news outlets are cited as their source.
- When data is missing, write "No HG data available for X".
- Keep the customer's product and its fit to the target account front and center.
- The plan must serve the customer's reps AND prove HG's value; a generic data dump fails both.
